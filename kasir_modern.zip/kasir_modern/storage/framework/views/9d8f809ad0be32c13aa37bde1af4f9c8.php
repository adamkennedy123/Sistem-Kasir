

<?php $__env->startSection('title', 'Transaksi Baru'); ?>

<?php $__env->startSection('header', 'Transaksi Baru'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('orders.store')); ?>"
      method="POST"
      id="orderForm">

    <?php echo csrf_field(); ?>

    <div class="grid grid-cols-1 xl:grid-cols-3 gap-4 sm:gap-6">

        

        <div class="xl:col-span-2">

            <div class="glass rounded-2xl p-4 sm:p-6">

                
                <div class="flex flex-col sm:flex-row
                            sm:justify-between
                            sm:items-center
                            gap-4
                            mb-5 sm:mb-6">

                    <div>

                        <h3 class="text-lg sm:text-xl font-bold">
                            Pilih Menu
                        </h3>

                        <p class="text-zinc-500 text-xs sm:text-sm mt-1">
                            Tambahkan makanan atau minuman
                        </p>

                    </div>


                    
                    <div class="w-full sm:w-auto">

                        <input
                            type="text"
                            id="searchProduct"
                            placeholder="Cari menu..."
                            class="w-full sm:w-56
                                   bg-zinc-900
                                   border border-zinc-700
                                   rounded-lg
                                   px-4 py-2.5
                                   text-sm
                                   outline-none
                                   focus:border-blue-500">

                    </div>

                </div>


                
                <div class="grid grid-cols-2
                            sm:grid-cols-3
                            lg:grid-cols-3
                            gap-3 sm:gap-4"
                     id="productList">

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <button
                            type="button"
                            class="product-card
                                   text-left
                                   bg-zinc-900
                                   border border-zinc-800
                                   hover:border-blue-500
                                   rounded-xl
                                   p-3 sm:p-4
                                   transition
                                   min-w-0"
                            data-id="<?php echo e($product->id); ?>"
                            data-name="<?php echo e($product->nama_produk); ?>"
                            data-price="<?php echo e($product->harga_jual); ?>"
                            data-stock="<?php echo e($product->stok); ?>">

                            <div class="text-[10px] sm:text-xs
                                        text-blue-400
                                        mb-2
                                        truncate">

                                <?php echo e($product->category->nama_kategori); ?>


                            </div>


                            <div class="font-bold
                                        text-sm sm:text-base
                                        break-words
                                        line-clamp-2">

                                <?php echo e($product->nama_produk); ?>


                            </div>


                            <div class="text-blue-400
                                        font-semibold
                                        text-sm sm:text-base
                                        mt-2
                                        whitespace-nowrap">

                                Rp <?php echo e(number_format(
                                    $product->harga_jual,
                                    0,
                                    ',',
                                    '.'
                                )); ?>


                            </div>


                            <div class="text-[10px] sm:text-xs
                                        text-zinc-500
                                        mt-1">

                                Stok: <?php echo e($product->stok); ?>


                            </div>

                        </button>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        </div>


        

        <div>

            <div class="glass rounded-2xl
                        p-4 sm:p-6
                        xl:sticky xl:top-5">

                <h3 class="text-lg sm:text-xl font-bold mb-5">
                    Detail Pesanan
                </h3>


                
                <label class="text-xs sm:text-sm text-zinc-400">
                    Tipe Pesanan
                </label>

                <select
                    name="tipe_pesanan"
                    id="tipePesanan"
                    required
                    class="w-full mt-2
                           bg-zinc-900
                           border border-zinc-700
                           rounded-lg
                           px-3 py-3
                           text-sm">

                    <option value="dine_in">
                        Dine-In
                    </option>

                    <option value="takeaway">
                        Takeaway
                    </option>

                </select>


                
                <div id="tableWrapper" class="mt-4">

                    <label class="text-xs sm:text-sm text-zinc-400">
                        Nomor Meja
                    </label>

                    <input
                        type="text"
                        name="nomor_meja"
                        class="w-full mt-2
                               bg-zinc-900
                               border border-zinc-700
                               rounded-lg
                               px-3 py-3
                               text-sm
                               outline-none
                               focus:border-blue-500"
                        placeholder="Contoh: A01">

                </div>


                
                <div class="mt-4">

                    <label class="text-xs sm:text-sm text-zinc-400">
                        Nama Pemesan / Catatan Meja
                    </label>

                    <input
                        type="text"
                        name="nama_pemesan"
                        class="w-full mt-2
                               bg-zinc-900
                               border border-zinc-700
                               rounded-lg
                               px-3 py-3
                               text-sm
                               outline-none
                               focus:border-blue-500"
                        placeholder="Nama pelanggan">

                </div>


                
                <div class="mt-6">

                    <div class="flex justify-between
                                items-center
                                mb-3">

                        <span class="text-zinc-400 text-sm">
                            Item Pesanan
                        </span>

                        <span id="itemCount"
                              class="text-sm">

                            0 item

                        </span>

                    </div>


                    <div id="cart"
                         class="space-y-3
                                max-h-72
                                sm:max-h-80
                                overflow-y-auto
                                pr-1">

                        <div id="emptyCart"
                             class="text-center
                                    text-zinc-600
                                    py-8
                                    text-sm">

                            Belum ada item.

                        </div>

                    </div>

                </div>


                
                <div class="border-t border-zinc-800
                            mt-6 pt-5
                            space-y-3">

                    <div class="flex justify-between
                                gap-3
                                text-sm">

                        <span class="text-zinc-400">
                            Subtotal
                        </span>

                        <span id="subtotalDisplay"
                              class="text-right whitespace-nowrap">

                            Rp 0

                        </span>

                    </div>


                    <div class="flex justify-between
                                gap-3
                                text-sm">

                        <span class="text-zinc-400">
                            Pajak 10%
                        </span>

                        <span id="taxDisplay"
                              class="text-right whitespace-nowrap">

                            Rp 0

                        </span>

                    </div>


                    
                    <div>

                        <label class="text-xs sm:text-sm
                                      text-zinc-400">

                            Diskon

                        </label>

                        <input
                            type="number"
                            name="diskon_nominal"
                            id="diskon"
                            value="0"
                            min="0"
                            class="w-full mt-2
                                   bg-zinc-900
                                   border border-zinc-700
                                   rounded-lg
                                   px-3 py-2.5
                                   text-sm
                                   outline-none
                                   focus:border-blue-500">

                    </div>


                    
                    <div class="flex justify-between
                                items-start
                                gap-3
                                text-lg font-bold
                                pt-1">

                        <span>
                            Grand Total
                        </span>

                        <span id="grandTotalDisplay"
                              class="text-blue-400
                                     text-right
                                     whitespace-nowrap">

                            Rp 0

                        </span>

                    </div>

                </div>


                
                <div class="mt-6">

                    <label class="text-xs sm:text-sm
                                  text-zinc-400">

                        Metode Pembayaran

                    </label>

                    <select
                        name="metode_bayar"
                        id="metodeBayar"
                        required
                        class="w-full mt-2
                               bg-zinc-900
                               border border-zinc-700
                               rounded-lg
                               px-3 py-3
                               text-sm">

                        <option value="cash">
                            Cash
                        </option>

                        <option value="qris">
                            QRIS
                        </option>

                        <option value="transfer">
                            Transfer Bank
                        </option>

                        <option value="debit">
                            Kartu Debit
                        </option>

                    </select>

                </div>


                
                <div id="cashWrapper" class="mt-4">

                    <label class="text-xs sm:text-sm
                                  text-zinc-400">

                        Uang Dibayar

                    </label>

                    <input
                        type="number"
                        name="uang_dibayar"
                        id="uangDibayar"
                        min="0"
                        value="0"
                        class="w-full mt-2
                               bg-zinc-900
                               border border-zinc-700
                               rounded-lg
                               px-3 py-3
                               text-sm
                               outline-none
                               focus:border-blue-500">


                    <div class="flex justify-between
                                gap-3
                                mt-3
                                text-sm">

                        <span class="text-zinc-500">
                            Kembalian
                        </span>

                        <span id="changeDisplay"
                              class="text-green-400
                                     font-bold
                                     text-right
                                     whitespace-nowrap">

                            Rp 0

                        </span>

                    </div>

                </div>


                
                <button
                    type="submit"
                    class="w-full mt-6
                           bg-blue-600
                           hover:bg-blue-700
                           py-3
                           rounded-lg
                           font-bold
                           text-sm sm:text-base
                           transition">

                    Simpan Transaksi

                </button>

            </div>

        </div>

    </div>

</form>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<script>

let cart = {};

const productButtons =
    document.querySelectorAll('.product-card');

const cartElement =
    document.getElementById('cart');

const subtotalDisplay =
    document.getElementById('subtotalDisplay');

const taxDisplay =
    document.getElementById('taxDisplay');

const grandTotalDisplay =
    document.getElementById('grandTotalDisplay');

const itemCount =
    document.getElementById('itemCount');

const diskonInput =
    document.getElementById('diskon');

const uangDibayarInput =
    document.getElementById('uangDibayar');

const changeDisplay =
    document.getElementById('changeDisplay');


/*
|--------------------------------------------------------------------------
| FORMAT RUPIAH
|--------------------------------------------------------------------------
*/

function rupiah(value)
{
    return 'Rp ' +
        new Intl.NumberFormat('id-ID').format(value);
}


/*
|--------------------------------------------------------------------------
| TAMBAH PRODUK
|--------------------------------------------------------------------------
*/

productButtons.forEach(button => {

    button.addEventListener('click', function () {

        const id =
            this.dataset.id;

        const name =
            this.dataset.name;

        const price =
            parseFloat(this.dataset.price);

        const stock =
            parseInt(this.dataset.stock);


        if (cart[id]) {

            if (cart[id].qty >= stock) {

                alert('Jumlah melebihi stok tersedia.');

                return;
            }

            cart[id].qty++;

        } else {

            cart[id] = {

                id: id,

                name: name,

                price: price,

                stock: stock,

                qty: 1,

                note: ''

            };
        }


        renderCart();

    });

});


/*
|--------------------------------------------------------------------------
| RENDER CART
|--------------------------------------------------------------------------
*/

function renderCart()
{
    cartElement.innerHTML = '';

    const items =
        Object.values(cart);


    if (items.length === 0) {

        cartElement.innerHTML = `
            <div class="text-center text-zinc-600 py-8">
                Belum ada item.
            </div>
        `;

        itemCount.textContent = '0 item';

        calculateTotal();

        return;
    }


    let totalItems = 0;


    items.forEach((item, index) => {

        totalItems += item.qty;


        const div =
            document.createElement('div');


        div.className =
            'bg-zinc-900 border border-zinc-800 rounded-lg p-3';


        div.innerHTML = `

            <div class="flex justify-between items-start gap-3">

                <div class="min-w-0">

                    <div class="font-semibold break-words">
                        ${item.name}
                    </div>

                    <div class="text-xs sm:text-sm text-zinc-500">
                        ${rupiah(item.price)}
                    </div>

                </div>

                <button
                    type="button"
                    onclick="removeItem('${item.id}')"
                    class="text-red-400
                           text-xl
                           leading-none
                           flex-shrink-0">

                    ×

                </button>

            </div>


            <div class="flex items-center gap-2 mt-3">

                <button
                    type="button"
                    onclick="decreaseQty('${item.id}')"
                    class="bg-zinc-800
                           hover:bg-zinc-700
                           w-8 h-8
                           rounded
                           flex-shrink-0">

                    −

                </button>


                <span class="w-8 text-center">
                    ${item.qty}
                </span>


                <button
                    type="button"
                    onclick="increaseQty('${item.id}')"
                    class="bg-zinc-800
                           hover:bg-zinc-700
                           w-8 h-8
                           rounded
                           flex-shrink-0">

                    +

                </button>


                <span class="ml-auto
                             font-semibold
                             text-sm
                             text-right
                             whitespace-nowrap">

                    ${rupiah(item.price * item.qty)}

                </span>

            </div>


            <input
                type="text"
                placeholder="Catatan khusus..."
                value="${item.note}"
                onchange="updateNote('${item.id}', this.value)"
                class="w-full mt-3
                       bg-zinc-800
                       border border-zinc-700
                       rounded
                       px-2 py-2
                       text-sm
                       outline-none
                       focus:border-blue-500">


            <input
                type="hidden"
                name="items[${index}][product_id]"
                value="${item.id}">


            <input
                type="hidden"
                name="items[${index}][kuantiti]"
                value="${item.qty}">


            <input
                type="hidden"
                name="items[${index}][catatan_khusus]"
                value="${item.note}">

        `;


        cartElement.appendChild(div);

    });


    itemCount.textContent =
        totalItems + ' item';


    calculateTotal();
}


/*
|--------------------------------------------------------------------------
| TAMBAH QTY
|--------------------------------------------------------------------------
*/

function increaseQty(id)
{
    const item = cart[id];

    if (item.qty >= item.stock) {

        alert('Stok tidak mencukupi.');

        return;
    }

    item.qty++;

    renderCart();
}


/*
|--------------------------------------------------------------------------
| KURANGI QTY
|--------------------------------------------------------------------------
*/

function decreaseQty(id)
{
    if (cart[id].qty <= 1) {

        delete cart[id];

    } else {

        cart[id].qty--;

    }

    renderCart();
}


/*
|--------------------------------------------------------------------------
| HAPUS ITEM
|--------------------------------------------------------------------------
*/

function removeItem(id)
{
    delete cart[id];

    renderCart();
}


/*
|--------------------------------------------------------------------------
| CATATAN
|--------------------------------------------------------------------------
*/

function updateNote(id, value)
{
    cart[id].note = value;

    renderCart();
}


function calculateTotal()
{
    let subtotal = 0;


    Object.values(cart).forEach(item => {

        subtotal +=
            item.price * item.qty;

    });


    const tax =
        subtotal * 0.10;


    let discount =
        parseFloat(diskonInput.value) || 0;


    if (discount > subtotal + tax) {

        discount =
            subtotal + tax;

    }


    const grandTotal =
        subtotal +
        tax -
        discount;


    subtotalDisplay.textContent =
        rupiah(subtotal);

    taxDisplay.textContent =
        rupiah(tax);

    grandTotalDisplay.textContent =
        rupiah(grandTotal);


    calculateChange(grandTotal);
}

function calculateChange(grandTotal)
{
    const paymentMethod =
        document.getElementById('metodeBayar').value;


    if (paymentMethod !== 'cash') {

        changeDisplay.textContent =
            rupiah(0);

        return;
    }


    const paid =
        parseFloat(
            uangDibayarInput.value
        ) || 0;


    const change =
        paid - grandTotal;


    changeDisplay.textContent =
        rupiah(
            change > 0
                ? change
                : 0
        );
}

diskonInput.addEventListener(
    'input',
    calculateTotal
);

uangDibayarInput.addEventListener(
    'input',
    calculateTotal
);

document
    .getElementById('metodeBayar')
    .addEventListener('change', function () {

        const cashWrapper =
            document.getElementById('cashWrapper');


        if (this.value === 'cash') {

            cashWrapper.style.display =
                'block';

        } else {

            cashWrapper.style.display =
                'none';

        }


        calculateTotal();

    });

document
    .getElementById('tipePesanan')
    .addEventListener('change', function () {

        const wrapper =
            document.getElementById('tableWrapper');


        if (this.value === 'dine_in') {

            wrapper.style.display =
                'block';

        } else {

            wrapper.style.display =
                'none';

        }

    });

document
    .getElementById('searchProduct')
    .addEventListener('input', function () {

        const keyword =
            this.value.toLowerCase();


        productButtons.forEach(button => {

            const name =
                button.dataset.name
                    .toLowerCase();


            button.style.display =
                name.includes(keyword)
                    ? 'block'
                    : 'none';

        });

    });


renderCart();

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Adam\OneDrive\Dokumen\Website\kasir_modern\resources\views/orders/create.blade.php ENDPATH**/ ?>