

<?php $__env->startSection('title', 'Laporan'); ?>

<?php $__env->startSection('header', 'Laporan Penjualan'); ?>

<?php $__env->startSection('content'); ?>



<div class="glass rounded-2xl p-6 mb-6">

    <form
        action="<?php echo e(route('reports.index')); ?>"
        method="GET">

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4">

            

            <div>

                <label class="text-sm text-zinc-400">
                    Tanggal Mulai
                </label>

                <input
                    type="date"
                    name="tanggal_mulai"
                    value="<?php echo e($tanggalMulai); ?>"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

            </div>


            

            <div>

                <label class="text-sm text-zinc-400">
                    Tanggal Selesai
                </label>

                <input
                    type="date"
                    name="tanggal_selesai"
                    value="<?php echo e($tanggalSelesai); ?>"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

            </div>


            

            <div>

                <label class="text-sm text-zinc-400">
                    Kategori
                </label>

                <select
                    name="category_id"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                    <option value="">
                        Semua Kategori
                    </option>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option
                            value="<?php echo e($category->id); ?>"
                            <?php if(
                                request('category_id')
                                == $category->id
                            ): echo 'selected'; endif; ?>>

                            <?php echo e($category->nama_kategori); ?>


                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>


            

            <div>

                <label class="text-sm text-zinc-400">
                    Pembayaran
                </label>

                <select
                    name="metode_bayar"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                    <option value="">
                        Semua Metode
                    </option>

                    <option
                        value="cash"
                        <?php if(request('metode_bayar') === 'cash'): echo 'selected'; endif; ?>>
                        Cash
                    </option>

                    <option
                        value="qris"
                        <?php if(request('metode_bayar') === 'qris'): echo 'selected'; endif; ?>>
                        QRIS
                    </option>

                    <option
                        value="transfer"
                        <?php if(request('metode_bayar') === 'transfer'): echo 'selected'; endif; ?>>
                        Transfer
                    </option>

                    <option
                        value="debit"
                        <?php if(request('metode_bayar') === 'debit'): echo 'selected'; endif; ?>>
                        Debit
                    </option>

                </select>

            </div>


            

            <div class="flex items-end">

                <button
                    class="w-full bg-blue-600 hover:bg-blue-700 px-4 py-3 rounded-lg font-semibold">

                    Terapkan Filter

                </button>

            </div>

        </div>

    </form>

</div>




<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4 mb-6">

    

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            TRANSAKSI
        </div>

        <div class="text-2xl font-bold mt-2">
            <?php echo e($jumlahTransaksi); ?>

        </div>

    </div>


    

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            OMSET BRUTO
        </div>

        <div class="text-xl font-bold mt-2 text-blue-400">

            Rp <?php echo e(number_format(
                $omsetBruto,
                0,
                ',',
                '.'
            )); ?>


        </div>

    </div>


    

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            TOTAL DISKON
        </div>

        <div class="text-xl font-bold mt-2 text-red-400">

            Rp <?php echo e(number_format(
                $totalDiskon,
                0,
                ',',
                '.'
            )); ?>


        </div>

    </div>


    

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            TOTAL PAJAK
        </div>

        <div class="text-xl font-bold mt-2 text-yellow-400">

            Rp <?php echo e(number_format(
                $totalPajak,
                0,
                ',',
                '.'
            )); ?>


        </div>

    </div>


    

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            OMSET BERSIH
        </div>

        <div class="text-xl font-bold mt-2 text-green-400">

            Rp <?php echo e(number_format(
                $omsetBersih,
                0,
                ',',
                '.'
            )); ?>


        </div>

    </div>

</div>




<div class="glass rounded-xl p-5 mb-6">

    <div class="text-sm text-zinc-500">
        AVERAGE ORDER VALUE
    </div>

    <div class="text-2xl font-bold mt-2">

        Rp <?php echo e(number_format(
            $averageOrderValue,
            0,
            ',',
            '.'
        )); ?>


    </div>

</div>




<div class="flex flex-wrap gap-3 mb-6">

    <a
        href="<?php echo e(route('reports.export', array_merge(
            request()->query(),
            ['type' => 'csv']
        ))); ?>"
        class="bg-green-600 hover:bg-green-700 px-5 py-3 rounded-lg font-semibold">

        ↓ Export CSV

    </a>


    <a
        href="<?php echo e(route('reports.export', array_merge(
            request()->query(),
            ['type' => 'pdf']
        ))); ?>"
        class="bg-red-600 hover:bg-red-700 px-5 py-3 rounded-lg font-semibold">

        ↓ Export PDF

    </a>

</div>




<div class="glass rounded-2xl overflow-hidden mb-6">

    <div class="p-6 border-b border-zinc-800">

        <h3 class="font-bold text-lg">
            Penjualan per Kategori
        </h3>

    </div>


    <div class="overflow-x-auto">

        <table class="w-full">

            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4">
                        Kategori
                    </th>

                    <th class="text-left p-4">
                        Item Terjual
                    </th>

                    <th class="text-left p-4">
                        Total Penjualan
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $penjualanKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr class="border-t border-zinc-800">

                        <td class="p-4 font-semibold">

                            <?php echo e($kategori->nama_kategori); ?>


                        </td>

                        <td class="p-4">

                            <?php echo e($kategori->total_item); ?>


                        </td>

                        <td class="p-4">

                            Rp <?php echo e(number_format(
                                $kategori->total_penjualan,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="3"
                            class="p-6 text-center text-zinc-500">

                            Belum ada data.

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>




<div class="glass rounded-2xl overflow-hidden">

    <div class="p-6 border-b border-zinc-800">

        <h3 class="font-bold text-lg">
            Detail Transaksi
        </h3>

    </div>


    <div class="overflow-x-auto">

        <table class="w-full">

            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4">
                        Invoice
                    </th>

                    <th class="text-left p-4">
                        Tanggal
                    </th>

                    <th class="text-left p-4">
                        Kasir
                    </th>

                    <th class="text-left p-4">
                        Tipe
                    </th>

                    <th class="text-left p-4">
                        Pembayaran
                    </th>

                    <th class="text-left p-4">
                        Subtotal
                    </th>

                    <th class="text-left p-4">
                        Diskon
                    </th>

                    <th class="text-left p-4">
                        Pajak
                    </th>

                    <th class="text-left p-4">
                        Grand Total
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr class="border-t border-zinc-800">

                        <td class="p-4 text-blue-400">

                            <?php echo e($order->invoice_number); ?>


                        </td>

                        <td class="p-4">

                            <?php echo e($order->created_at
                                ->format('d/m/Y H:i')); ?>


                        </td>

                        <td class="p-4">

                            <?php echo e($order->user->nama_lengkap); ?>


                        </td>

                        <td class="p-4">

                            <?php echo e(strtoupper(
                                str_replace(
                                    '_',
                                    ' ',
                                    $order->tipe_pesanan
                                )
                            )); ?>


                        </td>

                        <td class="p-4 uppercase">

                            <?php echo e($order->metode_bayar); ?>


                        </td>

                        <td class="p-4">

                            Rp <?php echo e(number_format(
                                $order->total_subtotal,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                        <td class="p-4">

                            Rp <?php echo e(number_format(
                                $order->diskon_nominal,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                        <td class="p-4">

                            Rp <?php echo e(number_format(
                                $order->pajak_nominal,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                        <td class="p-4 font-bold">

                            Rp <?php echo e(number_format(
                                $order->grand_total,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="9"
                            class="p-8 text-center text-zinc-500">

                            Tidak ada transaksi pada periode tersebut.

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Adam\OneDrive\Dokumen\Website\kasir_modern\resources\views/reports/index.blade.php ENDPATH**/ ?>