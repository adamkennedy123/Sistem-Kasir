

<?php $__env->startSection('title', 'Transaksi'); ?>

<?php $__env->startSection('header', 'Transaksi'); ?>

<?php $__env->startSection('content'); ?>


<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">

    <div>

        <h3 class="text-lg sm:text-xl font-bold">
            Riwayat Transaksi
        </h3>

        <p class="text-zinc-500 text-xs sm:text-sm mt-1">
            Daftar transaksi kasir
        </p>

    </div>


    <a href="<?php echo e(route('orders.create')); ?>"
       class="bg-blue-600
              hover:bg-blue-700
              px-5 py-3
              rounded-lg
              font-semibold
              text-center
              whitespace-nowrap
              transition">

        + Transaksi Baru

    </a>

</div>



<div class="glass rounded-2xl overflow-hidden">

    
    <div class="overflow-x-auto">

        <table class="w-full min-w-[950px] text-sm">

            
            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4 whitespace-nowrap">
                        Invoice
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Tanggal
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Kasir
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Tipe
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Pembayaran
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Total
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Status
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Aksi
                    </th>

                </tr>

            </thead>


            
            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr class="border-t border-zinc-800
                               hover:bg-zinc-900/50
                               transition">


                        
                        <td class="p-4
                                   text-blue-400
                                   font-medium
                                   whitespace-nowrap">

                            <?php echo e($order->invoice_number); ?>


                        </td>


                        
                        <td class="p-4 whitespace-nowrap">

                            <?php echo e($order->created_at->format('d/m/Y H:i')); ?>


                        </td>


                        
                        <td class="p-4 whitespace-nowrap">

                            <?php echo e($order->user->nama_lengkap); ?>


                        </td>


                        
                        <td class="p-4 whitespace-nowrap">

                            <?php echo e(strtoupper(
                                str_replace('_', ' ', $order->tipe_pesanan)
                            )); ?>


                        </td>


                        
                        <td class="p-4 uppercase whitespace-nowrap">

                            <?php echo e($order->metode_bayar); ?>


                        </td>


                        
                        <td class="p-4 font-semibold whitespace-nowrap">

                            Rp <?php echo e(number_format(
                                $order->grand_total,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>


                        
                        <td class="p-4 whitespace-nowrap">

                            <?php if($order->status === 'selesai'): ?>

                                <span class="inline-flex
                                             items-center
                                             px-2.5 py-1
                                             rounded-md
                                             bg-green-500/10
                                             text-green-400
                                             text-xs
                                             font-medium">

                                    Selesai

                                </span>


                            <?php elseif($order->status === 'dibatalkan'): ?>

                                <span class="inline-flex
                                             items-center
                                             px-2.5 py-1
                                             rounded-md
                                             bg-red-500/10
                                             text-red-400
                                             text-xs
                                             font-medium">

                                    Dibatalkan

                                </span>


                            <?php else: ?>

                                <span class="inline-flex
                                             items-center
                                             px-2.5 py-1
                                             rounded-md
                                             bg-yellow-500/10
                                             text-yellow-400
                                             text-xs
                                             font-medium">

                                    Diproses

                                </span>

                            <?php endif; ?>

                        </td>


                        
                        <td class="p-4 whitespace-nowrap">

                            <a href="<?php echo e(route('orders.show', $order)); ?>"
                               class="inline-flex
                                      items-center
                                      px-3 py-1.5
                                      rounded-md
                                      bg-blue-500/10
                                      text-blue-400
                                      hover:bg-blue-500/20
                                      hover:text-blue-300
                                      text-xs
                                      font-medium
                                      transition">

                                Detail

                            </a>

                        </td>

                    </tr>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="8"
                            class="p-8 text-center text-zinc-500">

                            Belum ada transaksi.

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>


    
    <div class="p-4 sm:p-5 border-t border-zinc-800 overflow-x-auto">

        <?php echo e($orders->links()); ?>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Adam\OneDrive\Dokumen\Website\kasir_modern\resources\views/orders/index.blade.php ENDPATH**/ ?>