

<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('header', 'Master Menu'); ?>

<?php $__env->startSection('content'); ?>

<div class="flex justify-between items-center mb-6">

    <div>

        <h3 class="text-xl font-bold">
            Menu Makanan & Minuman
        </h3>

        <p class="text-zinc-500 text-sm">
            Kelola harga, stok, dan kategori menu
        </p>

    </div>

    <a
        href="<?php echo e(route('products.create')); ?>"
        class="bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-lg font-semibold">

        + Tambah Produk

    </a>

</div>




<div class="glass rounded-2xl p-5 mb-6">

    <form
        method="GET"
        action="<?php echo e(route('products.index')); ?>"
        class="grid grid-cols-1 md:grid-cols-3 gap-4">

        <input
            type="text"
            name="search"
            value="<?php echo e(request('search')); ?>"
            placeholder="Cari kode / nama produk..."
            class="bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

        <select
            name="category_id"
            class="bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

            <option value="">
                Semua Kategori
            </option>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option
                    value="<?php echo e($category->id); ?>"
                    <?php if(request('category_id') == $category->id): echo 'selected'; endif; ?>>

                    <?php echo e($category->nama_kategori); ?>


                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>


        <div class="flex gap-2">

            <button
                class="bg-blue-600 hover:bg-blue-700 px-5 rounded-lg">

                Filter

            </button>

            <a
                href="<?php echo e(route('products.index')); ?>"
                class="bg-zinc-800 hover:bg-zinc-700 px-5 rounded-lg flex items-center">

                Reset

            </a>

        </div>

    </form>

</div>




<div class="glass rounded-2xl overflow-hidden">

    <div class="overflow-x-auto">

        <table class="w-full">

            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4">
                        Kode
                    </th>

                    <th class="text-left p-4">
                        Produk
                    </th>

                    <th class="text-left p-4">
                        Kategori
                    </th>

                    <th class="text-left p-4">
                        Harga Jual
                    </th>

                    <th class="text-left p-4">
                        HPP
                    </th>

                    <th class="text-left p-4">
                        Stok
                    </th>

                    <th class="text-left p-4">
                        Unit
                    </th>

                    <th class="text-left p-4">
                        Aksi
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr class="border-t border-zinc-800">

                        <td class="p-4 text-blue-400">
                            <?php echo e($product->kode_produk); ?>

                        </td>

                        <td class="p-4 font-semibold">
                            <?php echo e($product->nama_produk); ?>

                        </td>

                        <td class="p-4">
                            <?php echo e($product->category->nama_kategori); ?>

                        </td>

                        <td class="p-4">

                            Rp <?php echo e(number_format(
                                $product->harga_jual,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                        <td class="p-4">

                            Rp <?php echo e(number_format(
                                $product->harga_pokok,
                                0,
                                ',',
                                '.'
                            )); ?>


                        </td>

                        <td class="p-4">

                            <?php if($product->stok <= 5): ?>

                                <span class="text-red-400 font-bold">
                                    <?php echo e($product->stok); ?>

                                </span>

                            <?php else: ?>

                                <span class="text-green-400">
                                    <?php echo e($product->stok); ?>

                                </span>

                            <?php endif; ?>

                        </td>

                        <td class="p-4">
                            <?php echo e($product->unit); ?>

                        </td>

                        <td class="p-4">

                            <div class="flex gap-3">

                                <a
                                    href="<?php echo e(route('products.edit', $product)); ?>"
                                    class="text-blue-400">

                                    Edit

                                </a>

                                <form
                                    action="<?php echo e(route('products.destroy', $product)); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Hapus produk ini?')">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button
                                        class="text-red-400">

                                        Hapus

                                    </button>

                                </form>

                            </div>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="8"
                            class="p-8 text-center text-zinc-500">

                            Produk tidak ditemukan.

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>


    <div class="p-4 border-t border-zinc-800">

        <?php echo e($products->links()); ?>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Adam\OneDrive\Dokumen\Website\kasir_modern\resources\views/products/index.blade.php ENDPATH**/ ?>