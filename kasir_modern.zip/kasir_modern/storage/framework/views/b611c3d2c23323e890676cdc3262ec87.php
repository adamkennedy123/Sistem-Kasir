

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('header', 'Dashboard Eksekutif'); ?>

<?php $__env->startSection('content'); ?>

<div class="w-full max-w-full min-w-0 overflow-hidden">


    

    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-5">


        

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                TOTAL OMSET HARI INI
            </div>

            <div class="text-xl sm:text-2xl font-bold mt-3 text-blue-400 break-words">

                Rp <?php echo e(number_format($totalOmset, 0, ',', '.')); ?>


            </div>

            <div class="text-xs text-zinc-500 mt-2">
                Penjualan selesai hari ini
            </div>

        </div>



        

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                JUMLAH PESANAN
            </div>

            <div class="text-xl sm:text-2xl font-bold mt-3">
                <?php echo e($jumlahPesanan); ?>

            </div>

            <div class="text-xs text-zinc-500 mt-2">
                Transaksi selesai
            </div>

        </div>



        

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                MENU TERLARIS
            </div>


            <?php if($menuTerlaris): ?>

                <div class="text-lg sm:text-xl font-bold mt-3 break-words">

                    <?php echo e($menuTerlaris->nama_produk); ?>


                </div>

                <div class="text-xs text-green-400 mt-2">

                    <?php echo e($menuTerlaris->total_terjual); ?> terjual

                </div>

            <?php else: ?>

                <div class="text-zinc-500 mt-3">

                    Belum ada transaksi

                </div>

            <?php endif; ?>

        </div>



        

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                PERINGATAN STOK RENDAH
            </div>

            <div class="text-xl sm:text-2xl font-bold mt-3 text-red-400">

                <?php echo e($stokRendah->count()); ?>


            </div>

            <div class="text-xs text-zinc-500 mt-2">

                Produk stok ≤ 5

            </div>

        </div>

    </div>



    

    <div class="mt-6 sm:mt-8">

        <div class="flex flex-col sm:flex-row gap-3">

            

            <a href="<?php echo e(route('orders.create')); ?>"
               class="bg-blue-600
                      hover:bg-blue-700
                      px-5 py-3
                      rounded-lg
                      font-semibold
                      text-center
                      transition">

                + Transaksi Baru

            </a>



            

            <?php if(auth()->user()->role === 'admin'): ?>

                <a href="<?php echo e(route('products.create')); ?>"
                   class="bg-zinc-800
                          hover:bg-zinc-700
                          px-5 py-3
                          rounded-lg
                          text-center
                          transition">

                    + Tambah Produk

                </a>

            <?php endif; ?>

        </div>

    </div>



    

    <div class="glass rounded-2xl p-4 sm:p-6 mt-6 sm:mt-8 min-w-0">

        <div class="mb-5">

            <h3 class="font-bold text-base sm:text-lg">
                Grafik Omset
            </h3>

            <p class="text-zinc-500 text-xs sm:text-sm">
                Performa 7 hari terakhir
            </p>

        </div>


        

        <div class="relative w-full h-64 sm:h-72 md:h-80">

            <canvas id="salesChart"></canvas>

        </div>

    </div>



    

    <div class="glass rounded-2xl mt-6 sm:mt-8 overflow-hidden min-w-0">


        

        <div class="p-4 sm:p-6 border-b border-zinc-800">

            <h3 class="font-bold text-base sm:text-lg">
                Transaksi Terbaru
            </h3>

            <p class="text-xs text-zinc-500 mt-1">
                Daftar transaksi terbaru
            </p>

        </div>



        

        <div class="overflow-x-auto">

            <table class="w-full min-w-[700px] text-xs sm:text-sm">


                

                <thead class="bg-zinc-900">

                    <tr>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Invoice
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Kasir
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Tipe
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Total
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Status
                        </th>

                    </tr>

                </thead>



                

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $transaksiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="border-t border-zinc-800
                                   hover:bg-zinc-900/50
                                   transition">


                            

                            <td class="p-3 sm:p-4
                                       text-blue-400
                                       whitespace-nowrap">

                                <?php echo e($order->invoice_number); ?>


                            </td>



                            

                            <td class="p-3 sm:p-4 whitespace-nowrap">

                                <?php echo e($order->user->nama_lengkap); ?>


                            </td>



                            

                            <td class="p-3 sm:p-4 whitespace-nowrap">

                                <?php echo e(strtoupper(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $order->tipe_pesanan
                                    )
                                )); ?>


                            </td>



                            

                            <td class="p-3 sm:p-4 whitespace-nowrap">

                                Rp <?php echo e(number_format(
                                    $order->grand_total,
                                    0,
                                    ',',
                                    '.'
                                )); ?>


                            </td>



                            

                            <td class="p-3 sm:p-4 whitespace-nowrap">


                                <?php if($order->status === 'selesai'): ?>

                                    <span class="inline-flex
                                                 items-center
                                                 px-2 py-1
                                                 rounded-md
                                                 bg-green-500/10
                                                 text-green-400
                                                 text-xs">

                                        Selesai

                                    </span>


                                <?php elseif($order->status === 'dibatalkan'): ?>

                                    <span class="inline-flex
                                                 items-center
                                                 px-2 py-1
                                                 rounded-md
                                                 bg-red-500/10
                                                 text-red-400
                                                 text-xs">

                                        Dibatalkan

                                    </span>


                                <?php else: ?>

                                    <span class="inline-flex
                                                 items-center
                                                 px-2 py-1
                                                 rounded-md
                                                 bg-yellow-500/10
                                                 text-yellow-400
                                                 text-xs">

                                        Diproses

                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="5"
                                class="p-8
                                       text-center
                                       text-zinc-500">

                                Belum ada transaksi.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>





<?php $__env->startPush('scripts'); ?>

<script>

document.addEventListener('DOMContentLoaded', function () {


    const chartElement = document.getElementById('salesChart');


    if (!chartElement) {
        return;
    }


    const chartData = <?php echo json_encode($chart, 15, 512) ?>;


    const labels = chartData.map(function (item) {

        return item.tanggal;

    });


    const values = chartData.map(function (item) {

        return item.omset;

    });



    new Chart(chartElement, {

        type: 'line',


        data: {

            labels: labels,

            datasets: [{

                label: 'Omset',

                data: values,

                tension: 0.4,

                fill: true,

                borderWidth: 2

            }]

        },


        options: {

            responsive: true,

            maintainAspectRatio: false,


            interaction: {

                intersect: false,

                mode: 'index'

            },


            plugins: {

                legend: {

                    display: false

                },


                tooltip: {

                    callbacks: {

                        label: function (context) {

                            return 'Rp ' +

                                new Intl.NumberFormat('id-ID')
                                    .format(context.raw);

                        }

                    }

                }

            },


            scales: {

                x: {

                    ticks: {

                        color: '#71717a',

                        maxRotation: 0,

                        autoSkip: true,

                        maxTicksLimit: 7

                    },

                    grid: {

                        display: false

                    }

                },


                y: {

                    beginAtZero: true,


                    ticks: {

                        color: '#71717a',


                        callback: function (value) {

                            return 'Rp ' +

                                new Intl.NumberFormat('id-ID')
                                    .format(value);

                        }

                    }

                }

            }

        }

    });

});

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Adam\OneDrive\Dokumen\Website\kasir_modern\resources\views/dashboard.blade.php ENDPATH**/ ?>