<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with('user')
            ->latest()
            ->paginate(15);

        return view('orders.index', compact('orders'));
    }


    public function create()
    {
        $products = Product::with('category')
            ->where('stok', '>', 0)
            ->orderBy('nama_produk')
            ->get();

        return view('orders.create', compact('products'));
    }


    public function store(Request $request)
    {
        $validated = $request->validate([
            'tipe_pesanan' => [
                'required',
                'in:dine_in,takeaway'
            ],

            'nomor_meja' => [
                'nullable',
                'string',
                'max:50'
            ],

            'nama_pemesan' => [
                'nullable',
                'string',
                'max:100'
            ],

            'diskon_nominal' => [
                'nullable',
                'numeric',
                'min:0'
            ],

            'metode_bayar' => [
                'required',
                'in:cash,qris,transfer,debit'
            ],

            'uang_dibayar' => [
                'required_if:metode_bayar,cash',
                'numeric',
                'min:0'
            ],

            'items' => [
                'required',
                'array',
                'min:1'
            ],

            'items.*.product_id' => [
                'required',
                'exists:products,id'
            ],

            'items.*.kuantiti' => [
                'required',
                'integer',
                'min:1'
            ],

            'items.*.catatan_khusus' => [
                'nullable',
                'string',
                'max:500'
            ],
        ]);


        /*
        |--------------------------------------------------------------------------
        | TRANSACTION
        |--------------------------------------------------------------------------
        */

        $order = DB::transaction(function () use ($validated) {

            $subtotal = 0;

            $items = [];


            foreach ($validated['items'] as $item) {

                $product = Product::lockForUpdate()
                    ->findOrFail($item['product_id']);


                /*
                | VALIDASI STOK
                */

                if ($product->stok < $item['kuantiti']) {

                    throw new \Exception(
                        "Stok {$product->nama_produk} tidak mencukupi."
                    );
                }


                $lineSubtotal =
                    $product->harga_jual * $item['kuantiti'];


                $subtotal += $lineSubtotal;


                $items[] = [
                    'product' => $product,
                    'kuantiti' => $item['kuantiti'],
                    'harga_satuan' => $product->harga_jual,
                    'subtotal' => $lineSubtotal,
                    'catatan_khusus' =>
                        $item['catatan_khusus'] ?? null,
                ];
            }


            /*
            |--------------------------------------------------------------------------
            | PAJAK 10%
            |--------------------------------------------------------------------------
            */

            $pajak = $subtotal * 0.10;


            /*
            |--------------------------------------------------------------------------
            | DISKON
            |--------------------------------------------------------------------------
            */

            $diskon = $validated['diskon_nominal'] ?? 0;


            if ($diskon > ($subtotal + $pajak)) {

                throw new \Exception(
                    'Diskon tidak boleh lebih besar dari total transaksi.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | GRAND TOTAL
            |--------------------------------------------------------------------------
            */

            $grandTotal =
                $subtotal +
                $pajak -
                $diskon;


            /*
            |--------------------------------------------------------------------------
            | PEMBAYARAN
            |--------------------------------------------------------------------------
            */

            $uangDibayar =
                $validated['uang_dibayar'] ?? 0;


            if (
                $validated['metode_bayar'] === 'cash' &&
                $uangDibayar < $grandTotal
            ) {

                throw new \Exception(
                    'Uang pembayaran kurang dari total tagihan.'
                );
            }


            $uangKembali =
                $validated['metode_bayar'] === 'cash'
                    ? $uangDibayar - $grandTotal
                    : 0;


            /*
            |--------------------------------------------------------------------------
            | INVOICE
            |--------------------------------------------------------------------------
            */

            $invoice = $this->generateInvoice();


            /*
            |--------------------------------------------------------------------------
            | CREATE ORDER
            |--------------------------------------------------------------------------
            */

            $order = Order::create([

                'invoice_number' => $invoice,

                'user_id' => auth()->id(),

                'tipe_pesanan' =>
                    $validated['tipe_pesanan'],

                'nomor_meja' =>
                    $validated['nomor_meja'] ?? null,

                'nama_pemesan' =>
                    $validated['nama_pemesan'] ?? null,

                'total_subtotal' =>
                    $subtotal,

                'pajak_nominal' =>
                    $pajak,

                'diskon_nominal' =>
                    $diskon,

                'grand_total' =>
                    $grandTotal,

                'metode_bayar' =>
                    $validated['metode_bayar'],

                'uang_dibayar' =>
                    $uangDibayar,

                'uang_kembali' =>
                    $uangKembali,

                'status' =>
                    'selesai',
            ]);


            /*
            |--------------------------------------------------------------------------
            | DETAIL + UPDATE STOK
            |--------------------------------------------------------------------------
            */

            foreach ($items as $item) {

                $order->details()->create([

                    'product_id' =>
                        $item['product']->id,

                    'harga_satuan' =>
                        $item['harga_satuan'],

                    'kuantiti' =>
                        $item['kuantiti'],

                    'subtotal_baris' =>
                        $item['subtotal'],

                    'catatan_khusus' =>
                        $item['catatan_khusus'],

                ]);


                $item['product']->decrement(
                    'stok',
                    $item['kuantiti']
                );
            }


            return $order;
        });


        return redirect()
            ->route('orders.show', $order)
            ->with('success', 'Transaksi berhasil disimpan.');
    }


    public function show(Order $order)
    {
        $order->load([
            'user',
            'details.product.category'
        ]);

        return view('orders.show', compact('order'));
    }


    public function cancel(Order $order)
    {
        if ($order->status === 'dibatalkan') {

            return back()
                ->with('error', 'Transaksi sudah dibatalkan.');
        }


        DB::transaction(function () use ($order) {

            $order->load('details');


            /*
            | Kembalikan stok
            */

            foreach ($order->details as $detail) {

                Product::where('id', $detail->product_id)
                    ->increment(
                        'stok',
                        $detail->kuantiti
                    );
            }


            $order->update([
                'status' => 'dibatalkan'
            ]);
        });


        return back()
            ->with(
                'success',
                'Transaksi berhasil dibatalkan dan stok dikembalikan.'
            );
    }


    private function generateInvoice(): string
    {
        $prefix = 'INV-POS-' . now()->format('Ymd') . '-';


        $lastOrder = Order::whereDate(
                'created_at',
                now()->toDateString()
            )
            ->orderByDesc('id')
            ->first();


        if (!$lastOrder) {

            $number = 1;

        } else {

            $lastNumber =
                (int) substr(
                    $lastOrder->invoice_number,
                    -4
                );

            $number = $lastNumber + 1;
        }


        return $prefix .
            str_pad(
                $number,
                4,
                '0',
                STR_PAD_LEFT
            );
    }
}