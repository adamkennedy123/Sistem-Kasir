<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        $query = Order::with([
            'user',
            'details.product.category'
        ])
        ->where('status', 'selesai');


        /*
        |--------------------------------------------------------------------------
        | FILTER TANGGAL
        |--------------------------------------------------------------------------
        */

        $tanggalMulai = $request->input(
            'tanggal_mulai',
            now()->startOfMonth()->format('Y-m-d')
        );

        $tanggalSelesai = $request->input(
            'tanggal_selesai',
            now()->format('Y-m-d')
        );


        $query->whereDate(
            'created_at',
            '>=',
            $tanggalMulai
        );

        $query->whereDate(
            'created_at',
            '<=',
            $tanggalSelesai
        );


        /*
        |--------------------------------------------------------------------------
        | FILTER METODE PEMBAYARAN
        |--------------------------------------------------------------------------
        */

        if ($request->filled('metode_bayar')) {

            $query->where(
                'metode_bayar',
                $request->metode_bayar
            );
        }


        /*
        |--------------------------------------------------------------------------
        | FILTER KATEGORI
        |--------------------------------------------------------------------------
        */

        if ($request->filled('category_id')) {

            $categoryId =
                $request->category_id;


            $query->whereHas(
                'details.product',
                function ($q) use ($categoryId) {

                    $q->where(
                        'category_id',
                        $categoryId
                    );
                }
            );
        }


        /*
        |--------------------------------------------------------------------------
        | DATA TRANSAKSI
        |--------------------------------------------------------------------------
        */

        $orders = $query
            ->latest()
            ->get();


        /*
        |--------------------------------------------------------------------------
        | SUMMARY
        |--------------------------------------------------------------------------
        */

        $jumlahTransaksi =
            $orders->count();


        $omsetBruto =
            $orders->sum('total_subtotal');


        $totalDiskon =
            $orders->sum('diskon_nominal');


        $totalPajak =
            $orders->sum('pajak_nominal');


        $omsetBersih =
            $orders->sum('grand_total');


        $averageOrderValue =
            $jumlahTransaksi > 0
                ? $omsetBersih / $jumlahTransaksi
                : 0;


        /*
        |--------------------------------------------------------------------------
        | PENJUALAN PER KATEGORI
        |--------------------------------------------------------------------------
        */

        $penjualanKategori = DB::table('order_detail')
    ->join(
        'orders',
        'orders.id',
        '=',
        'order_detail.order_id'
    )
    ->join(
        'products',
        'products.id',
        '=',
        'order_detail.product_id'
    )
    ->join(
        'categories',
        'categories.id',
        '=',
        'products.category_id'
    )
    ->where('orders.status', 'selesai')
    ->whereDate(
        'orders.created_at',
        '>=',
        $tanggalMulai
    )
    ->whereDate(
        'orders.created_at',
        '<=',
        $tanggalSelesai
    )
    ->select(
        'categories.nama_kategori',
        DB::raw(
            'SUM(order_detail.kuantiti) as total_item'
        ),
        DB::raw(
            'SUM(order_detail.subtotal_baris) as total_penjualan'
        )
    )
    ->groupBy(
        'categories.id',
        'categories.nama_kategori'
    )
    ->orderByDesc('total_penjualan')
    ->get();

        $categories = Category::where('status', true)
            ->orderBy('nama_kategori')
            ->get();


        return view(
            'reports.index',
            compact(
                'orders',
                'categories',
                'tanggalMulai',
                'tanggalSelesai',
                'jumlahTransaksi',
                'omsetBruto',
                'totalDiskon',
                'totalPajak',
                'omsetBersih',
                'averageOrderValue',
                'penjualanKategori'
            )
        );
    }


    /*
    |--------------------------------------------------------------------------
    | EXPORT CSV
    |--------------------------------------------------------------------------
    */

    public function export(Request $request)
    {
        $type = $request->input(
            'type',
            'csv'
        );


        if ($type === 'pdf') {

            return $this->exportPdf($request);
        }


        return $this->exportCsv($request);
    }


    /*
    |--------------------------------------------------------------------------
    | CSV
    |--------------------------------------------------------------------------
    */

    private function exportCsv(Request $request)
    {
        $orders = $this->getFilteredOrders($request);


        $filename =
            'laporan-penjualan-' .
            now()->format('Ymd-His') .
            '.csv';


        return response()->streamDownload(
            function () use ($orders) {

                $handle = fopen(
                    'php://output',
                    'w'
                );


                /*
                | BOM agar Excel membaca UTF-8
                */

                fprintf(
                    $handle,
                    chr(0xEF) .
                    chr(0xBB) .
                    chr(0xBF)
                );


                fputcsv(
                    $handle,
                    [
                        'Invoice',
                        'Tanggal',
                        'Kasir',
                        'Tipe Pesanan',
                        'Metode Pembayaran',
                        'Subtotal',
                        'Pajak',
                        'Diskon',
                        'Grand Total',
                        'Status',
                    ]
                );


                foreach ($orders as $order) {

                    fputcsv(
                        $handle,
                        [
                            $order->invoice_number,

                            $order->created_at
                                ->format('d/m/Y H:i'),

                            $order->user
                                ->nama_lengkap,

                            strtoupper(
                                str_replace(
                                    '_',
                                    ' ',
                                    $order->tipe_pesanan
                                )
                            ),

                            strtoupper(
                                $order->metode_bayar
                            ),

                            $order->total_subtotal,

                            $order->pajak_nominal,

                            $order->diskon_nominal,

                            $order->grand_total,

                            strtoupper(
                                $order->status
                            ),
                        ]
                    );
                }


                fclose($handle);

            },
            $filename,
            [
                'Content-Type' =>
                    'text/csv; charset=UTF-8',
            ]
        );
    }


    /*
    |--------------------------------------------------------------------------
    | PDF
    |--------------------------------------------------------------------------
    */

    private function exportPdf(Request $request)
    {
        $orders =
            $this->getFilteredOrders($request);


        $jumlahTransaksi =
            $orders->count();


        $omsetBruto =
            $orders->sum('total_subtotal');


        $totalDiskon =
            $orders->sum('diskon_nominal');


        $totalPajak =
            $orders->sum('pajak_nominal');


        $omsetBersih =
            $orders->sum('grand_total');


        $averageOrderValue =
            $jumlahTransaksi > 0
                ? $omsetBersih / $jumlahTransaksi
                : 0;


        $pdf = Pdf::loadView(
            'reports.pdf',
            compact(
                'orders',
                'jumlahTransaksi',
                'omsetBruto',
                'totalDiskon',
                'totalPajak',
                'omsetBersih',
                'averageOrderValue'
            )
        );


        $pdf->setPaper(
            'a4',
            'landscape'
        );


        return $pdf->download(
            'laporan-penjualan-' .
            now()->format('Ymd-His') .
            '.pdf'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | FILTER DATA
    |--------------------------------------------------------------------------
    */

    private function getFilteredOrders(Request $request)
    {
        $query = Order::with('user')
            ->where('status', 'selesai');


        $tanggalMulai = $request->input(
            'tanggal_mulai',
            now()->startOfMonth()->format('Y-m-d')
        );


        $tanggalSelesai = $request->input(
            'tanggal_selesai',
            now()->format('Y-m-d')
        );


        $query->whereDate(
            'created_at',
            '>=',
            $tanggalMulai
        );


        $query->whereDate(
            'created_at',
            '<=',
            $tanggalSelesai
        );


        if ($request->filled('metode_bayar')) {

            $query->where(
                'metode_bayar',
                $request->metode_bayar
            );
        }


        if ($request->filled('category_id')) {

            $categoryId =
                $request->category_id;


            $query->whereHas(
                'details.product',
                function ($q) use ($categoryId) {

                    $q->where(
                        'category_id',
                        $categoryId
                    );
                }
            );
        }


        return $query
            ->latest()
            ->get();
    }
}