<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $today = now()->toDateString();

        $totalOmset = Order::whereDate('created_at', $today)
            ->where('status', 'selesai')
            ->sum('grand_total');

        $jumlahPesanan = Order::whereDate('created_at', $today)
            ->where('status', 'selesai')
            ->count();

        $menuTerlaris = DB::table('order_detail')
            ->join('orders', 'orders.id', '=', 'order_detail.order_id')
            ->join('products', 'products.id', '=', 'order_detail.product_id')
            ->whereDate('orders.created_at', $today)
            ->where('orders.status', 'selesai')
            ->select(
                'products.nama_produk',
                DB::raw('SUM(order_detail.kuantiti) as total_terjual')
            )
            ->groupBy('products.id', 'products.nama_produk')
            ->orderByDesc('total_terjual')
            ->first();

        $stokRendah = Product::where('stok', '<=', 5)
            ->orderBy('stok')
            ->get();

        $transaksiTerbaru = Order::with('user')
            ->latest()
            ->limit(10)
            ->get();

        $chart = [];

        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i);

            $chart[] = [
                'tanggal' => $date->format('d/m'),
                'omset' => Order::whereDate('created_at', $date->toDateString())
                    ->where('status', 'selesai')
                    ->sum('grand_total'),
            ];
        }

        return view('dashboard', compact(
            'totalOmset',
            'jumlahPesanan',
            'menuTerlaris',
            'stokRendah',
            'transaksiTerbaru',
            'chart'
        ));
    }
}