<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::with('category');

        if ($request->filled('search')) {

            $search = $request->search;

            $query->where(function ($q) use ($search) {

                $q->where('nama_produk', 'like', "%{$search}%")
                    ->orWhere('kode_produk', 'like', "%{$search}%");

            });
        }

        if ($request->filled('category_id')) {

            $query->where(
                'category_id',
                $request->category_id
            );
        }

        $products = $query
            ->latest()
            ->paginate(10)
            ->withQueryString();

        $categories = Category::where('status', true)
            ->orderBy('nama_kategori')
            ->get();

        return view(
            'products.index',
            compact('products', 'categories')
        );
    }

    public function create()
    {
        $categories = Category::where('status', true)
            ->orderBy('nama_kategori')
            ->get();

        return view(
            'products.create',
            compact('categories')
        );
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => [
                'required',
                'exists:categories,id',
            ],

            'kode_produk' => [
                'required',
                'string',
                'max:50',
                'unique:products,kode_produk',
            ],

            'nama_produk' => [
                'required',
                'string',
                'max:150',
            ],

            'harga_jual' => [
                'required',
                'numeric',
                'min:0',
            ],

            'harga_pokok' => [
                'required',
                'numeric',
                'min:0',
            ],

            'stok' => [
                'required',
                'integer',
                'min:0',
            ],

            'unit' => [
                'required',
                'string',
                'max:30',
            ],
        ]);

        Product::create($validated);

        return redirect()
            ->route('products.index')
            ->with(
                'success',
                'Produk berhasil ditambahkan.'
            );
    }

    public function edit(Product $product)
    {
        $categories = Category::where('status', true)
            ->orderBy('nama_kategori')
            ->get();

        return view(
            'products.edit',
            compact('product', 'categories')
        );
    }

    public function update(
        Request $request,
        Product $product
    ) {
        $validated = $request->validate([
            'category_id' => [
                'required',
                'exists:categories,id',
            ],

            'kode_produk' => [
                'required',
                'string',
                'max:50',
                'unique:products,kode_produk,' . $product->id,
            ],

            'nama_produk' => [
                'required',
                'string',
                'max:150',
            ],

            'harga_jual' => [
                'required',
                'numeric',
                'min:0',
            ],

            'harga_pokok' => [
                'required',
                'numeric',
                'min:0',
            ],

            'stok' => [
                'required',
                'integer',
                'min:0',
            ],

            'unit' => [
                'required',
                'string',
                'max:30',
            ],
        ]);

        $product->update($validated);

        return redirect()
            ->route('products.index')
            ->with(
                'success',
                'Produk berhasil diperbarui.'
            );
    }

    public function destroy(Product $product)
    {
        if ($product->orderDetails()->exists()) {

            return back()->with(
                'error',
                'Produk tidak dapat dihapus karena sudah digunakan dalam transaksi.'
            );
        }

        $product->delete();

        return back()->with(
            'success',
            'Produk berhasil dihapus.'
        );
    }
}