<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    protected $fillable = [
        'invoice_number',
        'user_id',
        'tipe_pesanan',
        'nomor_meja',
        'nama_pemesan',
        'total_subtotal',
        'pajak_nominal',
        'diskon_nominal',
        'grand_total',
        'metode_bayar',
        'uang_dibayar',
        'uang_kembali',
        'status',
    ];

    protected $casts = [
        'total_subtotal' => 'decimal:2',
        'pajak_nominal' => 'decimal:2',
        'diskon_nominal' => 'decimal:2',
        'grand_total' => 'decimal:2',
        'uang_dibayar' => 'decimal:2',
        'uang_kembali' => 'decimal:2',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function details(): HasMany
    {
        return $this->hasMany(OrderDetail::class);
    }
}