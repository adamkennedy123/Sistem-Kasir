@extends('layouts.app')

@section('title', 'Detail Transaksi')

@section('header', 'Detail Transaksi')

@section('content')

<div class="max-w-3xl mx-auto w-full">

    <div class="glass rounded-2xl p-4 sm:p-6 lg:p-8">

        {{-- HEADER TRANSAKSI --}}
        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-5">

            <div class="min-w-0">

                <div class="text-blue-400 font-bold text-sm">
                    TITIK TEMU KOPI
                </div>

                <h2 class="text-xl sm:text-2xl font-bold mt-2 break-all">
                    {{ $order->invoice_number }}
                </h2>

                <p class="text-zinc-500 text-xs sm:text-sm mt-1">
                    {{ $order->created_at->format('d M Y H:i') }}
                </p>

            </div>


            <div class="text-left sm:text-right">

                <div class="text-xs sm:text-sm text-zinc-500">
                    Kasir
                </div>

                <div class="font-medium">
                    {{ $order->user->nama_lengkap }}
                </div>

            </div>

        </div>


        <div class="border-t border-zinc-800 my-5 sm:my-6"></div>


        {{-- INFORMASI PESANAN --}}
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5 text-sm">

            {{-- TIPE PESANAN --}}
            <div>

                <div class="text-zinc-500 text-xs sm:text-sm">
                    Tipe Pesanan
                </div>

                <div class="font-semibold mt-1">
                    {{ strtoupper(
                        str_replace('_', ' ', $order->tipe_pesanan)
                    ) }}
                </div>

            </div>


            {{-- NOMOR MEJA --}}
            <div>

                <div class="text-zinc-500 text-xs sm:text-sm">
                    Nomor Meja
                </div>

                <div class="font-semibold mt-1">
                    {{ $order->nomor_meja ?? '-' }}
                </div>

            </div>


            {{-- PEMESAN --}}
            <div>

                <div class="text-zinc-500 text-xs sm:text-sm">
                    Pemesan
                </div>

                <div class="font-semibold mt-1 break-words">
                    {{ $order->nama_pemesan ?? '-' }}
                </div>

            </div>


            {{-- PEMBAYARAN --}}
            <div>

                <div class="text-zinc-500 text-xs sm:text-sm">
                    Pembayaran
                </div>

                <div class="font-semibold uppercase mt-1">
                    {{ $order->metode_bayar }}
                </div>

            </div>

        </div>


        <div class="border-t border-zinc-800 my-5 sm:my-6"></div>


        {{-- ITEM --}}
        <div class="space-y-4">

            @foreach($order->details as $detail)

                <div class="flex justify-between items-start gap-4">

                    {{-- PRODUCT --}}
                    <div class="min-w-0 flex-1">

                        <div class="font-semibold break-words">
                            {{ $detail->product->nama_produk }}
                        </div>

                        <div class="text-xs sm:text-sm text-zinc-500 mt-1">

                            {{ $detail->kuantiti }}
                            ×
                            Rp {{ number_format(
                                $detail->harga_satuan,
                                0,
                                ',',
                                '.'
                            ) }}

                        </div>


                        @if($detail->catatan_khusus)

                            <div class="text-xs text-zinc-600 mt-1 break-words">

                                Catatan:
                                {{ $detail->catatan_khusus }}

                            </div>

                        @endif

                    </div>


                    {{-- SUBTOTAL --}}
                    <div class="font-semibold
                                text-sm sm:text-base
                                text-right
                                whitespace-nowrap">

                        Rp {{ number_format(
                            $detail->subtotal_baris,
                            0,
                            ',',
                            '.'
                        ) }}

                    </div>

                </div>

            @endforeach

        </div>


        <div class="border-t border-zinc-800 my-5 sm:my-6"></div>


        {{-- TOTAL --}}
        <div class="space-y-3 text-sm">

            {{-- SUBTOTAL --}}
            <div class="flex justify-between gap-4">

                <span class="text-zinc-500">
                    Subtotal
                </span>

                <span class="text-right whitespace-nowrap">

                    Rp {{ number_format(
                        $order->total_subtotal,
                        0,
                        ',',
                        '.'
                    ) }}

                </span>

            </div>


            {{-- PAJAK --}}
            <div class="flex justify-between gap-4">

                <span class="text-zinc-500">
                    Pajak 10%
                </span>

                <span class="text-right whitespace-nowrap">

                    Rp {{ number_format(
                        $order->pajak_nominal,
                        0,
                        ',',
                        '.'
                    ) }}

                </span>

            </div>


            {{-- DISKON --}}
            <div class="flex justify-between gap-4">

                <span class="text-zinc-500">
                    Diskon
                </span>

                <span class="text-right whitespace-nowrap">

                    Rp {{ number_format(
                        $order->diskon_nominal,
                        0,
                        ',',
                        '.'
                    ) }}

                </span>

            </div>


            {{-- GRAND TOTAL --}}
            <div class="flex justify-between
                        items-start
                        gap-4
                        text-lg sm:text-xl
                        font-bold
                        pt-2">

                <span>
                    Grand Total
                </span>

                <span class="text-blue-400
                             text-right
                             whitespace-nowrap">

                    Rp {{ number_format(
                        $order->grand_total,
                        0,
                        ',',
                        '.'
                    ) }}

                </span>

            </div>


            {{-- CASH --}}
            @if($order->metode_bayar === 'cash')

                <div class="border-t border-zinc-800 my-3"></div>


                {{-- DIBAYAR --}}
                <div class="flex justify-between gap-4">

                    <span class="text-zinc-500">
                        Dibayar
                    </span>

                    <span class="text-right whitespace-nowrap">

                        Rp {{ number_format(
                            $order->uang_dibayar,
                            0,
                            ',',
                            '.'
                        ) }}

                    </span>

                </div>


                {{-- KEMBALIAN --}}
                <div class="flex justify-between gap-4">

                    <span class="text-zinc-500">
                        Kembalian
                    </span>

                    <span class="text-green-400
                                 text-right
                                 whitespace-nowrap">

                        Rp {{ number_format(
                            $order->uang_kembali,
                            0,
                            ',',
                            '.'
                        ) }}

                    </span>

                </div>

            @endif

        </div>


        {{-- ACTION --}}
        <div class="mt-7 sm:mt-8 flex flex-col sm:flex-row gap-3">

            <button
                onclick="window.print()"
                class="bg-blue-600
                       hover:bg-blue-700
                       px-5 py-3
                       rounded-lg
                       font-semibold
                       text-center
                       transition
                       w-full sm:w-auto">

                🖨️ Cetak Struk

            </button>


            <a href="{{ route('orders.create') }}"
               class="bg-zinc-800
                      hover:bg-zinc-700
                      px-5 py-3
                      rounded-lg
                      text-center
                      transition
                      w-full sm:w-auto">

                Transaksi Baru

            </a>

        </div>

    </div>

</div>

@endsection


@push('styles')

<style>

@media print {

    body {
        background: white !important;
        color: black !important;
    }

    aside,
    header,
    button,
    a {
        display: none !important;
    }

    main {
        padding: 0 !important;
        margin: 0 !important;
    }

    .glass {
        background: white !important;
        border: none !important;
        color: black !important;
        box-shadow: none !important;
    }

}

</style>

@endpush