@extends('layouts.app')

@section('title', 'Transaksi')

@section('header', 'Transaksi')

@section('content')

{{-- HEADER --}}
<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">

    <div>

        <h3 class="text-lg sm:text-xl font-bold">
            Riwayat Transaksi
        </h3>

        <p class="text-zinc-500 text-xs sm:text-sm mt-1">
            Daftar transaksi kasir
        </p>

    </div>


    <a href="{{ route('orders.create') }}"
       class="bg-blue-600
              hover:bg-blue-700
              px-5 py-3
              rounded-lg
              font-semibold
              text-center
              whitespace-nowrap
              transition">

        + Transaksi Baru

    </a>

</div>


{{-- TABLE --}}
<div class="glass rounded-2xl overflow-hidden">

    {{-- SCROLL TABLE --}}
    <div class="overflow-x-auto">

        <table class="w-full min-w-[950px] text-sm">

            {{-- HEADER TABLE --}}
            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4 whitespace-nowrap">
                        Invoice
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Tanggal
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Kasir
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Tipe
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Pembayaran
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Total
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Status
                    </th>

                    <th class="text-left p-4 whitespace-nowrap">
                        Aksi
                    </th>

                </tr>

            </thead>


            {{-- BODY --}}
            <tbody>

                @forelse($orders as $order)

                    <tr class="border-t border-zinc-800
                               hover:bg-zinc-900/50
                               transition">


                        {{-- INVOICE --}}
                        <td class="p-4
                                   text-blue-400
                                   font-medium
                                   whitespace-nowrap">

                            {{ $order->invoice_number }}

                        </td>


                        {{-- TANGGAL --}}
                        <td class="p-4 whitespace-nowrap">

                            {{ $order->created_at->format('d/m/Y H:i') }}

                        </td>


                        {{-- KASIR --}}
                        <td class="p-4 whitespace-nowrap">

                            {{ $order->user->nama_lengkap }}

                        </td>


                        {{-- TIPE --}}
                        <td class="p-4 whitespace-nowrap">

                            {{ strtoupper(
                                str_replace('_', ' ', $order->tipe_pesanan)
                            ) }}

                        </td>


                        {{-- PEMBAYARAN --}}
                        <td class="p-4 uppercase whitespace-nowrap">

                            {{ $order->metode_bayar }}

                        </td>


                        {{-- TOTAL --}}
                        <td class="p-4 font-semibold whitespace-nowrap">

                            Rp {{ number_format(
                                $order->grand_total,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>


                        {{-- STATUS --}}
                        <td class="p-4 whitespace-nowrap">

                            @if($order->status === 'selesai')

                                <span class="inline-flex
                                             items-center
                                             px-2.5 py-1
                                             rounded-md
                                             bg-green-500/10
                                             text-green-400
                                             text-xs
                                             font-medium">

                                    Selesai

                                </span>


                            @elseif($order->status === 'dibatalkan')

                                <span class="inline-flex
                                             items-center
                                             px-2.5 py-1
                                             rounded-md
                                             bg-red-500/10
                                             text-red-400
                                             text-xs
                                             font-medium">

                                    Dibatalkan

                                </span>


                            @else

                                <span class="inline-flex
                                             items-center
                                             px-2.5 py-1
                                             rounded-md
                                             bg-yellow-500/10
                                             text-yellow-400
                                             text-xs
                                             font-medium">

                                    Diproses

                                </span>

                            @endif

                        </td>


                        {{-- AKSI --}}
                        <td class="p-4 whitespace-nowrap">

                            <a href="{{ route('orders.show', $order) }}"
                               class="inline-flex
                                      items-center
                                      px-3 py-1.5
                                      rounded-md
                                      bg-blue-500/10
                                      text-blue-400
                                      hover:bg-blue-500/20
                                      hover:text-blue-300
                                      text-xs
                                      font-medium
                                      transition">

                                Detail

                            </a>

                        </td>

                    </tr>


                @empty

                    <tr>

                        <td colspan="8"
                            class="p-8 text-center text-zinc-500">

                            Belum ada transaksi.

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    {{-- PAGINATION --}}
    <div class="p-4 sm:p-5 border-t border-zinc-800 overflow-x-auto">

        {{ $orders->links() }}

    </div>

</div>

@endsection