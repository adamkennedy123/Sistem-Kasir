<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        @yield('title', 'Kafe POS')
    </title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            background: #0f0f11;
        }

        .glass {
            background: #17171a;
            border: 1px solid #27272a;
        }

        .sidebar {
            background: #121214;
        }

        /* Sidebar transition */
        #sidebar {
            transition: transform 0.3s ease;
        }

        /* Overlay mobile */
        #sidebarOverlay {
            transition: opacity 0.3s ease;
        }

        /* Desktop */
        @media (min-width: 1024px) {
            #sidebar {
                transform: translateX(0) !important;
            }

            #sidebarOverlay {
                display: none !important;
            }
        }
    </style>

    @stack('styles')
</head>

<body class="text-white">

<div class="min-h-screen flex">

    {{-- MOBILE OVERLAY --}}
    <div id="sidebarOverlay"
         class="fixed inset-0 bg-black/60 z-40 hidden opacity-0 lg:hidden"
         onclick="closeSidebar()">
    </div>


    {{-- SIDEBAR --}}
    <aside id="sidebar"
           class="sidebar fixed lg:static inset-y-0 left-0
                  w-64 max-w-[85vw]
                  border-r border-zinc-800
                  min-h-screen z-50
                  transform -translate-x-full lg:translate-x-0">

        {{-- LOGO --}}
        <div class="p-6">

            <div class="text-blue-500 font-bold text-sm">
                KAFE POS
            </div>

            <h1 class="text-xl font-bold mt-2">
                Titik Temu Kopi
            </h1>

        </div>


        {{-- MENU --}}
        <nav class="px-4 space-y-2">

            <a href="{{ route('dashboard') }}"
               class="block px-4 py-3 rounded-lg hover:bg-zinc-800 transition">
                📊 Dashboard
            </a>

            <a href="{{ route('orders.index') }}"
               class="block px-4 py-3 rounded-lg hover:bg-zinc-800 transition">
                🧾 Transaksi
            </a>

            @if(auth()->user()->role === 'admin')

                <a href="{{ route('products.index') }}"
                   class="block px-4 py-3 rounded-lg hover:bg-zinc-800 transition">
                    ☕ Produk
                </a>

                <a href="{{ route('categories.index') }}"
                   class="block px-4 py-3 rounded-lg hover:bg-zinc-800 transition">
                    📁 Kategori
                </a>

                <a href="{{ route('reports.index') }}"
                   class="block px-4 py-3 rounded-lg hover:bg-zinc-800 transition">
                    📑 Laporan
                </a>

            @endif

        </nav>


        {{-- USER --}}
        <div class="absolute bottom-0 w-full p-4">

            <div class="glass rounded-xl p-4">

                <div class="text-sm text-zinc-400">
                    Login sebagai
                </div>

                <div class="font-semibold truncate">
                    {{ auth()->user()->nama_lengkap }}
                </div>

                <div class="text-xs text-blue-400 uppercase mt-1">
                    {{ auth()->user()->role }}
                </div>

                <form action="{{ route('logout') }}"
                      method="POST"
                      class="mt-4">

                    @csrf

                    <button
                        class="w-full bg-red-600 hover:bg-red-700
                               rounded-lg py-2 transition">
                        Logout
                    </button>

                </form>

            </div>

        </div>

    </aside>


    {{-- CONTENT --}}
    <main class="flex-1 min-w-0">


        {{-- HEADER --}}
        <header class="border-b border-zinc-800 px-4 sm:px-6 lg:px-8 py-4 sm:py-5">

            <div class="flex justify-between items-center gap-4">

                {{-- LEFT --}}
                <div class="flex items-center gap-3 min-w-0">

                    {{-- HAMBURGER MOBILE --}}
                    <button
                        onclick="openSidebar()"
                        class="lg:hidden flex-shrink-0
                               w-10 h-10 rounded-lg
                               bg-zinc-800 hover:bg-zinc-700
                               flex items-center justify-center
                               text-xl">

                        ☰

                    </button>


                    <div class="min-w-0">

                        <h2 class="text-xl sm:text-2xl font-bold truncate">
                            @yield('header')
                        </h2>

                        <p class="text-zinc-500 text-xs sm:text-sm">
                            Sistem Kasir & Pemesanan Kafe
                        </p>

                    </div>

                </div>


                {{-- DATE --}}
                <div class="text-xs sm:text-sm text-zinc-400 whitespace-nowrap hidden sm:block">

                    {{ now()->format('d M Y, H:i') }}

                </div>

            </div>

        </header>


        {{-- PAGE CONTENT --}}
        <div class="p-4 sm:p-6 lg:p-8">

            {{-- SUCCESS --}}
            @if(session('success'))

                <div class="mb-6
                            bg-green-500/10
                            border border-green-500/30
                            text-green-400
                            px-4 py-3
                            rounded-lg">

                    {{ session('success') }}

                </div>

            @endif


            {{-- ERROR --}}
            @if(session('error'))

                <div class="mb-6
                            bg-red-500/10
                            border border-red-500/30
                            text-red-400
                            px-4 py-3
                            rounded-lg">

                    {{ session('error') }}

                </div>

            @endif


            {{-- VALIDATION ERROR --}}
            @if($errors->any())

                <div class="mb-6
                            bg-red-500/10
                            border border-red-500/30
                            text-red-400
                            px-4 py-3
                            rounded-lg">

                    <ul class="list-disc ml-5">

                        @foreach($errors->all() as $error)

                            <li>{{ $error }}</li>

                        @endforeach

                    </ul>

                </div>

            @endif


            {{-- CONTENT --}}
            @yield('content')

        </div>

    </main>

</div>


{{-- SIDEBAR SCRIPT --}}
<script>

    function openSidebar() {

        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        sidebar.classList.remove('-translate-x-full');

        overlay.classList.remove('hidden');

        setTimeout(() => {
            overlay.classList.remove('opacity-0');
        }, 10);
    }


    function closeSidebar() {

        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        sidebar.classList.add('-translate-x-full');

        overlay.classList.add('opacity-0');

        setTimeout(() => {
            overlay.classList.add('hidden');
        }, 300);
    }


    // Tutup sidebar ketika klik menu di mobile
    document.querySelectorAll('#sidebar a').forEach(link => {

        link.addEventListener('click', function () {

            if (window.innerWidth < 1024) {
                closeSidebar();
            }

        });

    });


    // Jika layar berubah ke desktop
    window.addEventListener('resize', function () {

        if (window.innerWidth >= 1024) {

            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');

            sidebar.classList.remove('-translate-x-full');

            overlay.classList.add('hidden');
            overlay.classList.add('opacity-0');

        }

    });

</script>


@stack('scripts')

</body>
</html>
