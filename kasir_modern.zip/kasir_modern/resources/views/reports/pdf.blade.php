<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>
        Laporan Penjualan
    </title>

    <style>

        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 10px;
            color: #222;
        }

        h1 {
            margin: 0;
            font-size: 20px;
        }

        h2 {
            font-size: 14px;
            margin-top: 20px;
        }

        .header {
            border-bottom: 2px solid #222;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .summary {
            width: 100%;
            margin-bottom: 20px;
        }

        .summary td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .label {
            font-size: 8px;
            color: #777;
        }

        .value {
            font-size: 13px;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #eeeeee;
            font-weight: bold;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 6px;
        }

        .right {
            text-align: right;
        }

        .center {
            text-align: center;
        }

    </style>

</head>


<body>

<div class="header">

    <h1>
        TITIK TEMU KOPI
    </h1>

    <div>
        Laporan Penjualan
    </div>

    <div>
        Dicetak:
        {{ now()->format('d/m/Y H:i') }}
    </div>

</div>


<table class="summary">

    <tr>

        <td>

            <div class="label">
                TOTAL TRANSAKSI
            </div>

            <div class="value">
                {{ $jumlahTransaksi }}
            </div>

        </td>


        <td>

            <div class="label">
                OMSET BRUTO
            </div>

            <div class="value">
                Rp {{ number_format(
                    $omsetBruto,
                    0,
                    ',',
                    '.'
                ) }}
            </div>

        </td>


        <td>

            <div class="label">
                DISKON
            </div>

            <div class="value">
                Rp {{ number_format(
                    $totalDiskon,
                    0,
                    ',',
                    '.'
                ) }}
            </div>

        </td>


        <td>

            <div class="label">
                PAJAK
            </div>

            <div class="value">
                Rp {{ number_format(
                    $totalPajak,
                    0,
                    ',',
                    '.'
                ) }}
            </div>

        </td>


        <td>

            <div class="label">
                OMSET BERSIH
            </div>

            <div class="value">
                Rp {{ number_format(
                    $omsetBersih,
                    0,
                    ',',
                    '.'
                ) }}
            </div>

        </td>

    </tr>

</table>


<h2>
    Detail Penjualan
</h2>


<table>

    <thead>

        <tr>

            <th>
                No
            </th>

            <th>
                Invoice
            </th>

            <th>
                Tanggal
            </th>

            <th>
                Kasir
            </th>

            <th>
                Tipe
            </th>

            <th>
                Pembayaran
            </th>

            <th>
                Subtotal
            </th>

            <th>
                Diskon
            </th>

            <th>
                Pajak
            </th>

            <th>
                Grand Total
            </th>

        </tr>

    </thead>


    <tbody>

        @foreach($orders as $index => $order)

            <tr>

                <td class="center">
                    {{ $index + 1 }}
                </td>

                <td>
                    {{ $order->invoice_number }}
                </td>

                <td>
                    {{ $order->created_at
                        ->format('d/m/Y H:i') }}
                </td>

                <td>
                    {{ $order->user->nama_lengkap }}
                </td>

                <td>
                    {{ strtoupper(
                        str_replace(
                            '_',
                            ' ',
                            $order->tipe_pesanan
                        )
                    ) }}
                </td>

                <td>
                    {{ strtoupper(
                        $order->metode_bayar
                    ) }}
                </td>

                <td class="right">

                    Rp {{ number_format(
                        $order->total_subtotal,
                        0,
                        ',',
                        '.'
                    ) }}

                </td>

                <td class="right">

                    Rp {{ number_format(
                        $order->diskon_nominal,
                        0,
                        ',',
                        '.'
                    ) }}

                </td>

                <td class="right">

                    Rp {{ number_format(
                        $order->pajak_nominal,
                        0,
                        ',',
                        '.'
                    ) }}

                </td>

                <td class="right">

                    <strong>

                        Rp {{ number_format(
                            $order->grand_total,
                            0,
                            ',',
                            '.'
                        ) }}

                    </strong>

                </td>

            </tr>

        @endforeach

    </tbody>

</table>


<h2>
    Ringkasan
</h2>


<table>

    <tr>

        <td>
            Average Order Value
        </td>

        <td class="right">

            Rp {{ number_format(
                $averageOrderValue,
                0,
                ',',
                '.'
            ) }}

        </td>

    </tr>

    <tr>

        <td>
            Omset Bersih
        </td>

        <td class="right">

            <strong>

                Rp {{ number_format(
                    $omsetBersih,
                    0,
                    ',',
                    '.'
                ) }}

            </strong>

        </td>

    </tr>

</table>

</body>

</html>