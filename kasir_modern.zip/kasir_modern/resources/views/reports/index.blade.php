@extends('layouts.app')

@section('title', 'Laporan')

@section('header', 'Laporan Penjualan')

@section('content')

{{-- FILTER --}}

<div class="glass rounded-2xl p-6 mb-6">

    <form
        action="{{ route('reports.index') }}"
        method="GET">

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4">

            {{-- TANGGAL MULAI --}}

            <div>

                <label class="text-sm text-zinc-400">
                    Tanggal Mulai
                </label>

                <input
                    type="date"
                    name="tanggal_mulai"
                    value="{{ $tanggalMulai }}"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

            </div>


            {{-- TANGGAL SELESAI --}}

            <div>

                <label class="text-sm text-zinc-400">
                    Tanggal Selesai
                </label>

                <input
                    type="date"
                    name="tanggal_selesai"
                    value="{{ $tanggalSelesai }}"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

            </div>


            {{-- KATEGORI --}}

            <div>

                <label class="text-sm text-zinc-400">
                    Kategori
                </label>

                <select
                    name="category_id"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                    <option value="">
                        Semua Kategori
                    </option>

                    @foreach($categories as $category)

                        <option
                            value="{{ $category->id }}"
                            @selected(
                                request('category_id')
                                == $category->id
                            )>

                            {{ $category->nama_kategori }}

                        </option>

                    @endforeach

                </select>

            </div>


            {{-- PEMBAYARAN --}}

            <div>

                <label class="text-sm text-zinc-400">
                    Pembayaran
                </label>

                <select
                    name="metode_bayar"
                    class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                    <option value="">
                        Semua Metode
                    </option>

                    <option
                        value="cash"
                        @selected(request('metode_bayar') === 'cash')>
                        Cash
                    </option>

                    <option
                        value="qris"
                        @selected(request('metode_bayar') === 'qris')>
                        QRIS
                    </option>

                    <option
                        value="transfer"
                        @selected(request('metode_bayar') === 'transfer')>
                        Transfer
                    </option>

                    <option
                        value="debit"
                        @selected(request('metode_bayar') === 'debit')>
                        Debit
                    </option>

                </select>

            </div>


            {{-- BUTTON --}}

            <div class="flex items-end">

                <button
                    class="w-full bg-blue-600 hover:bg-blue-700 px-4 py-3 rounded-lg font-semibold">

                    Terapkan Filter

                </button>

            </div>

        </div>

    </form>

</div>


{{-- SUMMARY --}}

<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4 mb-6">

    {{-- TRANSAKSI --}}

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            TRANSAKSI
        </div>

        <div class="text-2xl font-bold mt-2">
            {{ $jumlahTransaksi }}
        </div>

    </div>


    {{-- OMSET BRUTO --}}

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            OMSET BRUTO
        </div>

        <div class="text-xl font-bold mt-2 text-blue-400">

            Rp {{ number_format(
                $omsetBruto,
                0,
                ',',
                '.'
            ) }}

        </div>

    </div>


    {{-- DISKON --}}

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            TOTAL DISKON
        </div>

        <div class="text-xl font-bold mt-2 text-red-400">

            Rp {{ number_format(
                $totalDiskon,
                0,
                ',',
                '.'
            ) }}

        </div>

    </div>


    {{-- PAJAK --}}

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            TOTAL PAJAK
        </div>

        <div class="text-xl font-bold mt-2 text-yellow-400">

            Rp {{ number_format(
                $totalPajak,
                0,
                ',',
                '.'
            ) }}

        </div>

    </div>


    {{-- OMSET BERSIH --}}

    <div class="glass rounded-xl p-5">

        <div class="text-xs text-zinc-500">
            OMSET BERSIH
        </div>

        <div class="text-xl font-bold mt-2 text-green-400">

            Rp {{ number_format(
                $omsetBersih,
                0,
                ',',
                '.'
            ) }}

        </div>

    </div>

</div>


{{-- AOV --}}

<div class="glass rounded-xl p-5 mb-6">

    <div class="text-sm text-zinc-500">
        AVERAGE ORDER VALUE
    </div>

    <div class="text-2xl font-bold mt-2">

        Rp {{ number_format(
            $averageOrderValue,
            0,
            ',',
            '.'
        ) }}

    </div>

</div>


{{-- EXPORT --}}

<div class="flex flex-wrap gap-3 mb-6">

    <a
        href="{{ route('reports.export', array_merge(
            request()->query(),
            ['type' => 'csv']
        )) }}"
        class="bg-green-600 hover:bg-green-700 px-5 py-3 rounded-lg font-semibold">

        ↓ Export CSV

    </a>


    <a
        href="{{ route('reports.export', array_merge(
            request()->query(),
            ['type' => 'pdf']
        )) }}"
        class="bg-red-600 hover:bg-red-700 px-5 py-3 rounded-lg font-semibold">

        ↓ Export PDF

    </a>

</div>


{{-- KATEGORI --}}

<div class="glass rounded-2xl overflow-hidden mb-6">

    <div class="p-6 border-b border-zinc-800">

        <h3 class="font-bold text-lg">
            Penjualan per Kategori
        </h3>

    </div>


    <div class="overflow-x-auto">

        <table class="w-full">

            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4">
                        Kategori
                    </th>

                    <th class="text-left p-4">
                        Item Terjual
                    </th>

                    <th class="text-left p-4">
                        Total Penjualan
                    </th>

                </tr>

            </thead>

            <tbody>

                @forelse($penjualanKategori as $kategori)

                    <tr class="border-t border-zinc-800">

                        <td class="p-4 font-semibold">

                            {{ $kategori->nama_kategori }}

                        </td>

                        <td class="p-4">

                            {{ $kategori->total_item }}

                        </td>

                        <td class="p-4">

                            Rp {{ number_format(
                                $kategori->total_penjualan,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="3"
                            class="p-6 text-center text-zinc-500">

                            Belum ada data.

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>

</div>


{{-- DETAIL TRANSAKSI --}}

<div class="glass rounded-2xl overflow-hidden">

    <div class="p-6 border-b border-zinc-800">

        <h3 class="font-bold text-lg">
            Detail Transaksi
        </h3>

    </div>


    <div class="overflow-x-auto">

        <table class="w-full">

            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4">
                        Invoice
                    </th>

                    <th class="text-left p-4">
                        Tanggal
                    </th>

                    <th class="text-left p-4">
                        Kasir
                    </th>

                    <th class="text-left p-4">
                        Tipe
                    </th>

                    <th class="text-left p-4">
                        Pembayaran
                    </th>

                    <th class="text-left p-4">
                        Subtotal
                    </th>

                    <th class="text-left p-4">
                        Diskon
                    </th>

                    <th class="text-left p-4">
                        Pajak
                    </th>

                    <th class="text-left p-4">
                        Grand Total
                    </th>

                </tr>

            </thead>

            <tbody>

                @forelse($orders as $order)

                    <tr class="border-t border-zinc-800">

                        <td class="p-4 text-blue-400">

                            {{ $order->invoice_number }}

                        </td>

                        <td class="p-4">

                            {{ $order->created_at
                                ->format('d/m/Y H:i') }}

                        </td>

                        <td class="p-4">

                            {{ $order->user->nama_lengkap }}

                        </td>

                        <td class="p-4">

                            {{ strtoupper(
                                str_replace(
                                    '_',
                                    ' ',
                                    $order->tipe_pesanan
                                )
                            ) }}

                        </td>

                        <td class="p-4 uppercase">

                            {{ $order->metode_bayar }}

                        </td>

                        <td class="p-4">

                            Rp {{ number_format(
                                $order->total_subtotal,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>

                        <td class="p-4">

                            Rp {{ number_format(
                                $order->diskon_nominal,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>

                        <td class="p-4">

                            Rp {{ number_format(
                                $order->pajak_nominal,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>

                        <td class="p-4 font-bold">

                            Rp {{ number_format(
                                $order->grand_total,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td
                            colspan="9"
                            class="p-8 text-center text-zinc-500">

                            Tidak ada transaksi pada periode tersebut.

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>

</div>

@endsection