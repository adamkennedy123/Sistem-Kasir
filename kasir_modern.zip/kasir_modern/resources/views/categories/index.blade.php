@extends('layouts.app')

@section('title', 'Kategori')

@section('header', 'Kategori Menu')

@section('content')

<div class="w-full">

    {{-- HEADER --}}
    <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">

        <div class="min-w-0">
            <h3 class="text-lg sm:text-xl font-bold">
                Kategori Produk
            </h3>

            <p class="text-zinc-500 text-sm mt-1">
                Kelola kategori makanan dan minuman
            </p>
        </div>

        <a
            href="{{ route('categories.create') }}"
            class="
                inline-flex
                items-center
                justify-center
                w-full sm:w-auto
                bg-blue-600
                hover:bg-blue-700
                px-5
                py-3
                rounded-lg
                font-semibold
                text-sm sm:text-base
                transition
            "
        >
            + Tambah Kategori
        </a>

    </div>


    {{-- TABLE CARD --}}
    <div class="glass rounded-2xl overflow-hidden">

        {{-- TABLE RESPONSIVE --}}
        <div class="overflow-x-auto">

            <table class="w-full min-w-[800px]">

                <thead class="bg-zinc-900">

                    <tr>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Nama Kategori
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Slug
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Jumlah Produk
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Status
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Aksi
                        </th>

                    </tr>

                </thead>


                <tbody>

                    @forelse($categories as $category)

                        <tr class="border-t border-zinc-800 hover:bg-zinc-900/50 transition">

                            {{-- NAMA --}}
                            <td class="p-3 sm:p-4 font-semibold whitespace-nowrap">
                                {{ $category->nama_kategori }}
                            </td>


                            {{-- SLUG --}}
                            <td class="p-3 sm:p-4 text-zinc-400 whitespace-nowrap">
                                {{ $category->slug }}
                            </td>


                            {{-- JUMLAH PRODUK --}}
                            <td class="p-3 sm:p-4 whitespace-nowrap">
                                {{ $category->products_count }}
                            </td>


                            {{-- STATUS --}}
                            <td class="p-3 sm:p-4 whitespace-nowrap">

                                @if($category->status)

                                    <span
                                        class="
                                            inline-flex
                                            items-center
                                            px-2.5
                                            py-1
                                            rounded-full
                                            text-xs
                                            font-semibold
                                            bg-green-500/10
                                            text-green-400
                                        "
                                    >
                                        Aktif
                                    </span>

                                @else

                                    <span
                                        class="
                                            inline-flex
                                            items-center
                                            px-2.5
                                            py-1
                                            rounded-full
                                            text-xs
                                            font-semibold
                                            bg-red-500/10
                                            text-red-400
                                        "
                                    >
                                        Nonaktif
                                    </span>

                                @endif

                            </td>


                            {{-- AKSI --}}
                            <td class="p-3 sm:p-4">

                                <div class="flex items-center gap-4 whitespace-nowrap">

                                    <a
                                        href="{{ route('categories.edit', $category) }}"
                                        class="
                                            text-blue-400
                                            hover:text-blue-300
                                            font-medium
                                            transition
                                        "
                                    >
                                        Edit
                                    </a>


                                    <form
                                        action="{{ route('categories.destroy', $category) }}"
                                        method="POST"
                                        onsubmit="return confirm('Hapus kategori ini?')"
                                    >

                                        @csrf
                                        @method('DELETE')

                                        <button
                                            type="submit"
                                            class="
                                                text-red-400
                                                hover:text-red-300
                                                font-medium
                                                transition
                                            "
                                        >
                                            Hapus
                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    @empty

                        <tr>

                            <td
                                colspan="5"
                                class="p-8 text-center text-zinc-500"
                            >
                                Belum ada kategori.
                            </td>

                        </tr>

                    @endforelse

                </tbody>

            </table>

        </div>


        {{-- PAGINATION --}}
        <div
            class="
                p-3 sm:p-4
                border-t border-zinc-800
                overflow-x-auto
            "
        >

            <div class="min-w-max">
                {{ $categories->links() }}
            </div>

        </div>

    </div>

</div>

@endsection