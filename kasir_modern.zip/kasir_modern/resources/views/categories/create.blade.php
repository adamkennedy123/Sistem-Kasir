@extends('layouts.app')

@section('title', 'Tambah Kategori')

@section('header', 'Tambah Kategori')

@section('content')

<div class="w-full max-w-xl mx-auto sm:mx-0">

    <div class="glass rounded-2xl p-4 sm:p-6">

        <form
            action="{{ route('categories.store') }}"
            method="POST"
        >

            @csrf


            {{-- NAMA KATEGORI --}}
            <div class="mb-5">

                <label class="text-sm text-zinc-400 block">
                    Nama Kategori
                </label>

                <input
                    type="text"
                    name="nama_kategori"
                    value="{{ old('nama_kategori') }}"
                    required
                    placeholder="Contoh: Coffee"
                    class="
                        w-full
                        mt-2
                        bg-zinc-900
                        border border-zinc-700
                        rounded-lg
                        px-4
                        py-3
                        text-sm sm:text-base
                        text-white
                        placeholder-zinc-500
                        focus:outline-none
                        focus:ring-2
                        focus:ring-blue-500
                        focus:border-blue-500
                        transition
                    "
                >

            </div>


            {{-- STATUS --}}
            <div class="mb-5">

                <label class="text-sm text-zinc-400 block">
                    Status
                </label>

                <select
                    name="status"
                    class="
                        w-full
                        mt-2
                        bg-zinc-900
                        border border-zinc-700
                        rounded-lg
                        px-4
                        py-3
                        text-sm sm:text-base
                        text-white
                        focus:outline-none
                        focus:ring-2
                        focus:ring-blue-500
                        focus:border-blue-500
                        transition
                    "
                >

                    <option value="1">
                        Aktif
                    </option>

                    <option value="0">
                        Nonaktif
                    </option>

                </select>

            </div>


            {{-- BUTTON --}}
            <div class="flex flex-col-reverse sm:flex-row gap-3">

                <a
                    href="{{ route('categories.index') }}"
                    class="
                        w-full sm:w-auto
                        bg-zinc-800
                        hover:bg-zinc-700
                        px-5
                        py-3
                        rounded-lg
                        text-center
                        text-sm sm:text-base
                        transition
                    "
                >
                    Kembali
                </a>


                <button
                    type="submit"
                    class="
                        w-full sm:w-auto
                        bg-blue-600
                        hover:bg-blue-700
                        px-5
                        py-3
                        rounded-lg
                        font-semibold
                        text-sm sm:text-base
                        transition
                    "
                >
                    Simpan
                </button>

            </div>

        </form>

    </div>

</div>

@endsection