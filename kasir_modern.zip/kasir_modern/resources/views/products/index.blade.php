@extends('layouts.app')

@section('title', 'Produk')

@section('header', 'Master Menu')

@section('content')

<div class="flex justify-between items-center mb-6">

    <div>

        <h3 class="text-xl font-bold">
            Menu Makanan & Minuman
        </h3>

        <p class="text-zinc-500 text-sm">
            Kelola harga, stok, dan kategori menu
        </p>

    </div>

    <a
        href="{{ route('products.create') }}"
        class="bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-lg font-semibold">

        + Tambah Produk

    </a>

</div>


{{-- FILTER --}}

<div class="glass rounded-2xl p-5 mb-6">

    <form
        method="GET"
        action="{{ route('products.index') }}"
        class="grid grid-cols-1 md:grid-cols-3 gap-4">

        <input
            type="text"
            name="search"
            value="{{ request('search') }}"
            placeholder="Cari kode / nama produk..."
            class="bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

        <select
            name="category_id"
            class="bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

            <option value="">
                Semua Kategori
            </option>

            @foreach($categories as $category)

                <option
                    value="{{ $category->id }}"
                    @selected(request('category_id') == $category->id)>

                    {{ $category->nama_kategori }}

                </option>

            @endforeach

        </select>


        <div class="flex gap-2">

            <button
                class="bg-blue-600 hover:bg-blue-700 px-5 rounded-lg">

                Filter

            </button>

            <a
                href="{{ route('products.index') }}"
                class="bg-zinc-800 hover:bg-zinc-700 px-5 rounded-lg flex items-center">

                Reset

            </a>

        </div>

    </form>

</div>


{{-- TABLE --}}

<div class="glass rounded-2xl overflow-hidden">

    <div class="overflow-x-auto">

        <table class="w-full">

            <thead class="bg-zinc-900">

                <tr>

                    <th class="text-left p-4">
                        Kode
                    </th>

                    <th class="text-left p-4">
                        Produk
                    </th>

                    <th class="text-left p-4">
                        Kategori
                    </th>

                    <th class="text-left p-4">
                        Harga Jual
                    </th>

                    <th class="text-left p-4">
                        HPP
                    </th>

                    <th class="text-left p-4">
                        Stok
                    </th>

                    <th class="text-left p-4">
                        Unit
                    </th>

                    <th class="text-left p-4">
                        Aksi
                    </th>

                </tr>

            </thead>

            <tbody>

                @forelse($products as $product)

                    <tr class="border-t border-zinc-800">

                        <td class="p-4 text-blue-400">
                            {{ $product->kode_produk }}
                        </td>

                        <td class="p-4 font-semibold">
                            {{ $product->nama_produk }}
                        </td>

                        <td class="p-4">
                            {{ $product->category->nama_kategori }}
                        </td>

                        <td class="p-4">

                            Rp {{ number_format(
                                $product->harga_jual,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>

                        <td class="p-4">

                            Rp {{ number_format(
                                $product->harga_pokok,
                                0,
                                ',',
                                '.'
                            ) }}

                        </td>

                        <td class="p-4">

                            @if($product->stok <= 5)

                                <span class="text-red-400 font-bold">
                                    {{ $product->stok }}
                                </span>

                            @else

                                <span class="text-green-400">
                                    {{ $product->stok }}
                                </span>

                            @endif

                        </td>

                        <td class="p-4">
                            {{ $product->unit }}
                        </td>

                        <td class="p-4">

                            <div class="flex gap-3">

                                <a
                                    href="{{ route('products.edit', $product) }}"
                                    class="text-blue-400">

                                    Edit

                                </a>

                                <form
                                    action="{{ route('products.destroy', $product) }}"
                                    method="POST"
                                    onsubmit="return confirm('Hapus produk ini?')">

                                    @csrf
                                    @method('DELETE')

                                    <button
                                        class="text-red-400">

                                        Hapus

                                    </button>

                                </form>

                            </div>

                        </td>

                    </tr>

                @empty

                    <tr>

                        <td colspan="8"
                            class="p-8 text-center text-zinc-500">

                            Produk tidak ditemukan.

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    <div class="p-4 border-t border-zinc-800">

        {{ $products->links() }}

    </div>

</div>

@endsection