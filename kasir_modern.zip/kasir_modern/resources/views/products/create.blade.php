@extends('layouts.app')

@section('title', 'Tambah Produk')

@section('header', 'Tambah Produk')

@section('content')

<div class="max-w-2xl">

    <div class="glass rounded-2xl p-6">

        <form
            action="{{ route('products.store') }}"
            method="POST">

            @csrf


            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">


                {{-- KATEGORI --}}

                <div>

                    <label class="text-sm text-zinc-400">
                        Kategori
                    </label>

                    <select
                        name="category_id"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                        <option value="">
                            Pilih kategori
                        </option>

                        @foreach($categories as $category)

                            <option
                                value="{{ $category->id }}"
                                @selected(old('category_id') == $category->id)>

                                {{ $category->nama_kategori }}

                            </option>

                        @endforeach

                    </select>

                </div>


                {{-- KODE --}}

                <div>

                    <label class="text-sm text-zinc-400">
                        Kode Produk
                    </label>

                    <input
                        type="text"
                        name="kode_produk"
                        value="{{ old('kode_produk') }}"
                        required
                        placeholder="CF001"
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                {{-- NAMA --}}

                <div class="md:col-span-2">

                    <label class="text-sm text-zinc-400">
                        Nama Produk
                    </label>

                    <input
                        type="text"
                        name="nama_produk"
                        value="{{ old('nama_produk') }}"
                        required
                        placeholder="Americano"
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                {{-- HARGA JUAL --}}

                <div>

                    <label class="text-sm text-zinc-400">
                        Harga Jual
                    </label>

                    <input
                        type="number"
                        name="harga_jual"
                        value="{{ old('harga_jual') }}"
                        min="0"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                {{-- HPP --}}

                <div>

                    <label class="text-sm text-zinc-400">
                        Harga Pokok
                    </label>

                    <input
                        type="number"
                        name="harga_pokok"
                        value="{{ old('harga_pokok', 0) }}"
                        min="0"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                {{-- STOK --}}

                <div>

                    <label class="text-sm text-zinc-400">
                        Stok
                    </label>

                    <input
                        type="number"
                        name="stok"
                        value="{{ old('stok', 0) }}"
                        min="0"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                {{-- UNIT --}}

                <div>

                    <label class="text-sm text-zinc-400">
                        Unit
                    </label>

                    <input
                        type="text"
                        name="unit"
                        value="{{ old('unit', 'pcs') }}"
                        required
                        placeholder="cup / pcs / porsi"
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>

            </div>


            <div class="flex gap-3 mt-6">

                <button
                    class="bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-lg">

                    Simpan Produk

                </button>

                <a
                    href="{{ route('products.index') }}"
                    class="bg-zinc-800 hover:bg-zinc-700 px-5 py-3 rounded-lg">

                    Kembali

                </a>

            </div>

        </form>

    </div>

</div>

@endsection