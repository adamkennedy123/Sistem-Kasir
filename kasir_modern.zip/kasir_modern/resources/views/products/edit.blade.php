@extends('layouts.app')

@section('title', 'Edit Produk')

@section('header', 'Edit Produk')

@section('content')

<div class="max-w-2xl">

    <div class="glass rounded-2xl p-6">

        <form
            action="{{ route('products.update', $product) }}"
            method="POST">

            @csrf
            @method('PUT')


            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">


                <div>

                    <label class="text-sm text-zinc-400">
                        Kategori
                    </label>

                    <select
                        name="category_id"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                        @foreach($categories as $category)

                            <option
                                value="{{ $category->id }}"
                                @selected(
                                    old(
                                        'category_id',
                                        $product->category_id
                                    ) == $category->id
                                )>

                                {{ $category->nama_kategori }}

                            </option>

                        @endforeach

                    </select>

                </div>


                <div>

                    <label class="text-sm text-zinc-400">
                        Kode Produk
                    </label>

                    <input
                        type="text"
                        name="kode_produk"
                        value="{{ old(
                            'kode_produk',
                            $product->kode_produk
                        ) }}"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                <div class="md:col-span-2">

                    <label class="text-sm text-zinc-400">
                        Nama Produk
                    </label>

                    <input
                        type="text"
                        name="nama_produk"
                        value="{{ old(
                            'nama_produk',
                            $product->nama_produk
                        ) }}"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                <div>

                    <label class="text-sm text-zinc-400">
                        Harga Jual
                    </label>

                    <input
                        type="number"
                        name="harga_jual"
                        value="{{ old(
                            'harga_jual',
                            $product->harga_jual
                        ) }}"
                        min="0"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                <div>

                    <label class="text-sm text-zinc-400">
                        Harga Pokok
                    </label>

                    <input
                        type="number"
                        name="harga_pokok"
                        value="{{ old(
                            'harga_pokok',
                            $product->harga_pokok
                        ) }}"
                        min="0"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                <div>

                    <label class="text-sm text-zinc-400">
                        Stok
                    </label>

                    <input
                        type="number"
                        name="stok"
                        value="{{ old(
                            'stok',
                            $product->stok
                        ) }}"
                        min="0"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>


                <div>

                    <label class="text-sm text-zinc-400">
                        Unit
                    </label>

                    <input
                        type="text"
                        name="unit"
                        value="{{ old(
                            'unit',
                            $product->unit
                        ) }}"
                        required
                        class="w-full mt-2 bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-3">

                </div>

            </div>


            <div class="flex gap-3 mt-6">

                <button
                    class="bg-blue-600 hover:bg-blue-700 px-5 py-3 rounded-lg">

                    Update Produk

                </button>

                <a
                    href="{{ route('products.index') }}"
                    class="bg-zinc-800 hover:bg-zinc-700 px-5 py-3 rounded-lg">

                    Kembali

                </a>

            </div>

        </form>

    </div>

</div>

@endsection