<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Login - Kafe POS</title>

    {{-- TAILWIND CSS --}}
    <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="min-h-screen bg-gray-100 flex items-center justify-center px-4">

    <div class="w-full max-w-md">

        {{-- LOGIN CARD --}}
        <div class="bg-white rounded-2xl shadow-lg p-6 sm:p-8">

            {{-- HEADER --}}
            <div class="text-center mb-8">

                <div class="text-blue-600 font-bold text-sm">
                    KAFE POS
                </div>

                <h1 class="text-2xl font-bold text-gray-900 mt-2">
                    Titik Temu Kopi
                </h1>

                <p class="text-gray-500 text-sm mt-2">
                    Silakan masuk untuk melanjutkan
                </p>

            </div>


            {{-- ERROR --}}
            @if(session('error'))

                <div class="mb-5 bg-red-50 border border-red-200
                            text-red-600 px-4 py-3 rounded-lg text-sm">

                    {{ session('error') }}

                </div>

            @endif


            {{-- VALIDATION ERROR --}}
            @if($errors->any())

                <div class="mb-5 bg-red-50 border border-red-200
                            text-red-600 px-4 py-3 rounded-lg text-sm">

                    <ul class="list-disc ml-5">

                        @foreach($errors->all() as $error)

                            <li>{{ $error }}</li>

                        @endforeach

                    </ul>

                </div>

            @endif


            {{-- LOGIN FORM --}}
            <form action="{{ route('login.post') }}" method="POST">

                @csrf


                {{-- USERNAME --}}
                <div class="mb-4">

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Username
                    </label>

                    <input
                        type="text"
                        name="username"
                        value="{{ old('username') }}"
                        placeholder="Masukkan username"
                        required
                        autofocus
                        autocomplete="username"
                        class="w-full px-4 py-3
                               border border-gray-300
                               rounded-lg
                               text-gray-900
                               bg-white
                               focus:outline-none
                               focus:ring-2
                               focus:ring-gray-800
                               focus:border-transparent
                               transition"
                    >

                    @error('username')

                        <p class="text-red-500 text-sm mt-1">
                            {{ $message }}
                        </p>

                    @enderror

                </div>


                {{-- PASSWORD --}}
                <div class="mb-5">

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Password
                    </label>

                    <input
                        type="password"
                        name="password"
                        placeholder="Masukkan password"
                        required
                        autocomplete="current-password"
                        class="w-full px-4 py-3
                               border border-gray-300
                               rounded-lg
                               text-gray-900
                               bg-white
                               focus:outline-none
                               focus:ring-2
                               focus:ring-gray-800
                               focus:border-transparent
                               transition"
                    >

                    @error('password')

                        <p class="text-red-500 text-sm mt-1">
                            {{ $message }}
                        </p>

                    @enderror

                </div>


                {{-- BUTTON --}}
                <button
                    type="submit"
                    class="w-full
                           bg-gray-900
                           hover:bg-gray-800
                           active:bg-gray-950
                           text-white
                           font-semibold
                           py-3
                           rounded-lg
                           transition
                           duration-200">

                    Masuk

                </button>

            </form>

        </div>

        {{-- FOOTER --}}
        <p class="text-center text-gray-500 text-xs mt-5">
            © {{ date('Y') }} Kafe POS
        </p>

    </div>

</body>

</html>
