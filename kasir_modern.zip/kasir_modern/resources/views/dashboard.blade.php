@extends('layouts.app')

@section('title', 'Dashboard')

@section('header', 'Dashboard Eksekutif')

@section('content')

<div class="w-full max-w-full min-w-0 overflow-hidden">


    {{-- =====================================================
         STATISTIC CARDS
    ====================================================== --}}

    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-5">


        {{-- OMSET --}}

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                TOTAL OMSET HARI INI
            </div>

            <div class="text-xl sm:text-2xl font-bold mt-3 text-blue-400 break-words">

                Rp {{ number_format($totalOmset, 0, ',', '.') }}

            </div>

            <div class="text-xs text-zinc-500 mt-2">
                Penjualan selesai hari ini
            </div>

        </div>



        {{-- PESANAN --}}

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                JUMLAH PESANAN
            </div>

            <div class="text-xl sm:text-2xl font-bold mt-3">
                {{ $jumlahPesanan }}
            </div>

            <div class="text-xs text-zinc-500 mt-2">
                Transaksi selesai
            </div>

        </div>



        {{-- MENU TERLARIS --}}

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                MENU TERLARIS
            </div>


            @if($menuTerlaris)

                <div class="text-lg sm:text-xl font-bold mt-3 break-words">

                    {{ $menuTerlaris->nama_produk }}

                </div>

                <div class="text-xs text-green-400 mt-2">

                    {{ $menuTerlaris->total_terjual }} terjual

                </div>

            @else

                <div class="text-zinc-500 mt-3">

                    Belum ada transaksi

                </div>

            @endif

        </div>



        {{-- STOK --}}

        <div class="glass rounded-2xl p-4 sm:p-6 min-w-0">

            <div class="text-zinc-500 text-xs sm:text-sm">
                PERINGATAN STOK RENDAH
            </div>

            <div class="text-xl sm:text-2xl font-bold mt-3 text-red-400">

                {{ $stokRendah->count() }}

            </div>

            <div class="text-xs text-zinc-500 mt-2">

                Produk stok ≤ 5

            </div>

        </div>

    </div>



    {{-- =====================================================
         QUICK ACTION
    ====================================================== --}}

    <div class="mt-6 sm:mt-8">

        <div class="flex flex-col sm:flex-row gap-3">

            {{-- TRANSAKSI BARU --}}

            <a href="{{ route('orders.create') }}"
               class="bg-blue-600
                      hover:bg-blue-700
                      px-5 py-3
                      rounded-lg
                      font-semibold
                      text-center
                      transition">

                + Transaksi Baru

            </a>



            {{-- TAMBAH PRODUK --}}

            @if(auth()->user()->role === 'admin')

                <a href="{{ route('products.create') }}"
                   class="bg-zinc-800
                          hover:bg-zinc-700
                          px-5 py-3
                          rounded-lg
                          text-center
                          transition">

                    + Tambah Produk

                </a>

            @endif

        </div>

    </div>



    {{-- =====================================================
         CHART
    ====================================================== --}}

    <div class="glass rounded-2xl p-4 sm:p-6 mt-6 sm:mt-8 min-w-0">

        <div class="mb-5">

            <h3 class="font-bold text-base sm:text-lg">
                Grafik Omset
            </h3>

            <p class="text-zinc-500 text-xs sm:text-sm">
                Performa 7 hari terakhir
            </p>

        </div>


        {{-- CHART CONTAINER --}}

        <div class="relative w-full h-64 sm:h-72 md:h-80">

            <canvas id="salesChart"></canvas>

        </div>

    </div>



    {{-- =====================================================
         TRANSAKSI TERBARU
    ====================================================== --}}

    <div class="glass rounded-2xl mt-6 sm:mt-8 overflow-hidden min-w-0">


        {{-- HEADER TABLE --}}

        <div class="p-4 sm:p-6 border-b border-zinc-800">

            <h3 class="font-bold text-base sm:text-lg">
                Transaksi Terbaru
            </h3>

            <p class="text-xs text-zinc-500 mt-1">
                Daftar transaksi terbaru
            </p>

        </div>



        {{-- TABLE SCROLL --}}

        <div class="overflow-x-auto">

            <table class="w-full min-w-[700px] text-xs sm:text-sm">


                {{-- TABLE HEADER --}}

                <thead class="bg-zinc-900">

                    <tr>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Invoice
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Kasir
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Tipe
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Total
                        </th>

                        <th class="text-left p-3 sm:p-4 whitespace-nowrap">
                            Status
                        </th>

                    </tr>

                </thead>



                {{-- TABLE BODY --}}

                <tbody>

                    @forelse($transaksiTerbaru as $order)

                        <tr class="border-t border-zinc-800
                                   hover:bg-zinc-900/50
                                   transition">


                            {{-- INVOICE --}}

                            <td class="p-3 sm:p-4
                                       text-blue-400
                                       whitespace-nowrap">

                                {{ $order->invoice_number }}

                            </td>



                            {{-- KASIR --}}

                            <td class="p-3 sm:p-4 whitespace-nowrap">

                                {{ $order->user->nama_lengkap }}

                            </td>



                            {{-- TIPE --}}

                            <td class="p-3 sm:p-4 whitespace-nowrap">

                                {{ strtoupper(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $order->tipe_pesanan
                                    )
                                ) }}

                            </td>



                            {{-- TOTAL --}}

                            <td class="p-3 sm:p-4 whitespace-nowrap">

                                Rp {{ number_format(
                                    $order->grand_total,
                                    0,
                                    ',',
                                    '.'
                                ) }}

                            </td>



                            {{-- STATUS --}}

                            <td class="p-3 sm:p-4 whitespace-nowrap">


                                @if($order->status === 'selesai')

                                    <span class="inline-flex
                                                 items-center
                                                 px-2 py-1
                                                 rounded-md
                                                 bg-green-500/10
                                                 text-green-400
                                                 text-xs">

                                        Selesai

                                    </span>


                                @elseif($order->status === 'dibatalkan')

                                    <span class="inline-flex
                                                 items-center
                                                 px-2 py-1
                                                 rounded-md
                                                 bg-red-500/10
                                                 text-red-400
                                                 text-xs">

                                        Dibatalkan

                                    </span>


                                @else

                                    <span class="inline-flex
                                                 items-center
                                                 px-2 py-1
                                                 rounded-md
                                                 bg-yellow-500/10
                                                 text-yellow-400
                                                 text-xs">

                                        Diproses

                                    </span>

                                @endif

                            </td>

                        </tr>


                    @empty

                        <tr>

                            <td colspan="5"
                                class="p-8
                                       text-center
                                       text-zinc-500">

                                Belum ada transaksi.

                            </td>

                        </tr>

                    @endforelse

                </tbody>

            </table>

        </div>

    </div>

</div>

@endsection



{{-- =========================================================
     CHART SCRIPT
========================================================= --}}

@push('scripts')

<script>

document.addEventListener('DOMContentLoaded', function () {


    const chartElement = document.getElementById('salesChart');


    if (!chartElement) {
        return;
    }


    const chartData = @json($chart);


    const labels = chartData.map(function (item) {

        return item.tanggal;

    });


    const values = chartData.map(function (item) {

        return item.omset;

    });



    new Chart(chartElement, {

        type: 'line',


        data: {

            labels: labels,

            datasets: [{

                label: 'Omset',

                data: values,

                tension: 0.4,

                fill: true,

                borderWidth: 2

            }]

        },


        options: {

            responsive: true,

            maintainAspectRatio: false,


            interaction: {

                intersect: false,

                mode: 'index'

            },


            plugins: {

                legend: {

                    display: false

                },


                tooltip: {

                    callbacks: {

                        label: function (context) {

                            return 'Rp ' +

                                new Intl.NumberFormat('id-ID')
                                    .format(context.raw);

                        }

                    }

                }

            },


            scales: {

                x: {

                    ticks: {

                        color: '#71717a',

                        maxRotation: 0,

                        autoSkip: true,

                        maxTicksLimit: 7

                    },

                    grid: {

                        display: false

                    }

                },


                y: {

                    beginAtZero: true,


                    ticks: {

                        color: '#71717a',


                        callback: function (value) {

                            return 'Rp ' +

                                new Intl.NumberFormat('id-ID')
                                    .format(value);

                        }

                    }

                }

            }

        }

    });

});

</script>

@endpush
