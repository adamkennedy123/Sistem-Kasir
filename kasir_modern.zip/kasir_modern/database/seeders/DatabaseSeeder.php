<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'username' => 'admin',
            'nama_lengkap' => 'Administrator',
            'password' => Hash::make('admin'),
            'role' => 'admin',
            'status' => true,
        ]);

        User::create([
            'username' => 'kasir',
            'nama_lengkap' => 'Kasir Demo',
            'password' => Hash::make('kasir'),
            'role' => 'kasir',
            'status' => true,
        ]);

        $coffee = Category::create([
            'nama_kategori' => 'Coffee',
            'slug' => 'coffee',
            'status' => true,
        ]);

        $nonCoffee = Category::create([
            'nama_kategori' => 'Non-Coffee',
            'slug' => 'non-coffee',
            'status' => true,
        ]);

        $food = Category::create([
            'nama_kategori' => 'Food',
            'slug' => 'food',
            'status' => true,
        ]);

        Product::create([
            'category_id' => $coffee->id,
            'kode_produk' => 'CF001',
            'nama_produk' => 'Americano',
            'harga_jual' => 18000,
            'harga_pokok' => 8000,
            'stok' => 50,
            'unit' => 'cup',
        ]);

        Product::create([
            'category_id' => $coffee->id,
            'kode_produk' => 'CF002',
            'nama_produk' => 'Cappuccino',
            'harga_jual' => 22000,
            'harga_pokok' => 10000,
            'stok' => 40,
            'unit' => 'cup',
        ]);

        Product::create([
            'category_id' => $nonCoffee->id,
            'kode_produk' => 'NC001',
            'nama_produk' => 'Matcha Latte',
            'harga_jual' => 24000,
            'harga_pokok' => 11000,
            'stok' => 35,
            'unit' => 'cup',
        ]);

        Product::create([
            'category_id' => $food->id,
            'kode_produk' => 'FD001',
            'nama_produk' => 'French Fries',
            'harga_jual' => 20000,
            'harga_pokok' => 9000,
            'stok' => 30,
            'unit' => 'porsi',
        ]);
        User::updateOrCreate(
            ['email' => 'admin@cafe.test'],
            [
                'nama_lengkap' => 'Administrator',
                'password' => Hash::make('password123'),
                'role' => 'admin',
            ]
        );

        User::updateOrCreate(
            ['email' => 'kasir@cafe.test'],
            [
                'nama_lengkap' => 'Kasir Café',
                'password' => Hash::make('password123'),
                'role' => 'kasir',
            ]
        );
    }
}